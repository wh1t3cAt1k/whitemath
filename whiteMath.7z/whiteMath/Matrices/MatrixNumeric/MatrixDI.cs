﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace whiteMath.Matrices.MatrixNumeric
{
#if TODO
    class MatrixDI<T,C>: Matrix<T,C> where C: ICalc<T>, new()
    {
    }
#endif
}
