﻿namespace whiteMath.Graphers
{
    partial class GraphicDrawer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.fontDialogForGrapher = new System.Windows.Forms.FontDialog();
            this.colorDialogForGrapher = new System.Windows.Forms.ColorDialog();
            this.saveFileDialog = new System.Windows.Forms.SaveFileDialog();
            this.statusStrip = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabelCoord = new System.Windows.Forms.ToolStripStatusLabel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.numericUpDownAW = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownCW = new System.Windows.Forms.NumericUpDown();
            this.label23 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.checkBoxLineCurve = new System.Windows.Forms.CheckBox();
            this.checkBoxLineBroken = new System.Windows.Forms.CheckBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.numericUpDownEX2 = new System.Windows.Forms.NumericUpDown();
            this.buttonRestore = new System.Windows.Forms.Button();
            this.label18 = new System.Windows.Forms.Label();
            this.textBoxToY = new System.Windows.Forms.TextBox();
            this.textBoxFromY = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.numericUpDownParts = new System.Windows.Forms.NumericUpDown();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.numericUpDownEX = new System.Windows.Forms.NumericUpDown();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.numericUpDownShift = new System.Windows.Forms.NumericUpDown();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.textBoxToX = new System.Windows.Forms.TextBox();
            this.textBoxFromX = new System.Windows.Forms.TextBox();
            this.numericUpDownHeight = new System.Windows.Forms.NumericUpDown();
            this.label6 = new System.Windows.Forms.Label();
            this.numericUpDownWidth = new System.Windows.Forms.NumericUpDown();
            this.checkBoxNotWindowed = new System.Windows.Forms.CheckBox();
            this.checkBoxWindowed = new System.Windows.Forms.CheckBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.buttonChooseFont = new System.Windows.Forms.Button();
            this.richTextBoxFontTest = new System.Windows.Forms.RichTextBox();
            this.shapeContainer1 = new Microsoft.VisualBasic.PowerPacks.ShapeContainer();
            this.lineShape9 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape8 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape7 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape6 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape5 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape4 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape2 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape3 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape1 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.panel = new System.Windows.Forms.Panel();
            this.pictureBoxWindow = new System.Windows.Forms.PictureBox();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.buttonGraphToFile = new System.Windows.Forms.Button();
            this.buttonGraph = new System.Windows.Forms.Button();
            this.multiGrapherPens1 = new whiteMath.Graphers.Components.MultiGrapherPens();
            this.statusStrip.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownAW)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownCW)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownEX2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownParts)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownEX)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownShift)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownHeight)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownWidth)).BeginInit();
            this.panel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxWindow)).BeginInit();
            this.flowLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // fontDialogForGrapher
            // 
            this.fontDialogForGrapher.AllowVerticalFonts = false;
            this.fontDialogForGrapher.FontMustExist = true;
            this.fontDialogForGrapher.ShowEffects = false;
            // 
            // saveFileDialog
            // 
            this.saveFileDialog.DefaultExt = "png";
            this.saveFileDialog.Filter = "PNG files|*png|Bitmap|*.bmp|JPEG files|*.jpg";
            // 
            // statusStrip
            // 
            this.statusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel,
            this.toolStripStatusLabelCoord});
            this.statusStrip.Location = new System.Drawing.Point(0, 478);
            this.statusStrip.MinimumSize = new System.Drawing.Size(857, 22);
            this.statusStrip.Name = "statusStrip";
            this.statusStrip.Size = new System.Drawing.Size(857, 22);
            this.statusStrip.TabIndex = 41;
            this.statusStrip.Text = "statusStrip1";
            // 
            // toolStripStatusLabel
            // 
            this.toolStripStatusLabel.Name = "toolStripStatusLabel";
            this.toolStripStatusLabel.Size = new System.Drawing.Size(81, 17);
            this.toolStripStatusLabel.Text = "Координаты: ";
            // 
            // toolStripStatusLabelCoord
            // 
            this.toolStripStatusLabelCoord.Name = "toolStripStatusLabelCoord";
            this.toolStripStatusLabelCoord.Size = new System.Drawing.Size(67, 17);
            this.toolStripStatusLabelCoord.Text = "X = 0, Y = 0";
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 287F));
            this.tableLayoutPanel1.Controls.Add(this.groupBox1, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.panel, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.flowLayoutPanel1, 0, 1);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(800, 478);
            this.tableLayoutPanel1.TabIndex = 44;
            // 
            // groupBox1
            // 
            this.groupBox1.AutoSize = true;
            this.groupBox1.Controls.Add(this.numericUpDownAW);
            this.groupBox1.Controls.Add(this.numericUpDownCW);
            this.groupBox1.Controls.Add(this.label23);
            this.groupBox1.Controls.Add(this.label21);
            this.groupBox1.Controls.Add(this.label16);
            this.groupBox1.Controls.Add(this.checkBoxLineCurve);
            this.groupBox1.Controls.Add(this.checkBoxLineBroken);
            this.groupBox1.Controls.Add(this.label15);
            this.groupBox1.Controls.Add(this.label22);
            this.groupBox1.Controls.Add(this.label20);
            this.groupBox1.Controls.Add(this.label19);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.numericUpDownEX2);
            this.groupBox1.Controls.Add(this.multiGrapherPens1);
            this.groupBox1.Controls.Add(this.buttonRestore);
            this.groupBox1.Controls.Add(this.label18);
            this.groupBox1.Controls.Add(this.textBoxToY);
            this.groupBox1.Controls.Add(this.textBoxFromY);
            this.groupBox1.Controls.Add(this.label17);
            this.groupBox1.Controls.Add(this.numericUpDownParts);
            this.groupBox1.Controls.Add(this.label14);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.numericUpDownEX);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.numericUpDownShift);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.textBoxToX);
            this.groupBox1.Controls.Add(this.textBoxFromX);
            this.groupBox1.Controls.Add(this.numericUpDownHeight);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.numericUpDownWidth);
            this.groupBox1.Controls.Add(this.checkBoxNotWindowed);
            this.groupBox1.Controls.Add(this.checkBoxWindowed);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.buttonChooseFont);
            this.groupBox1.Controls.Add(this.richTextBoxFontTest);
            this.groupBox1.Controls.Add(this.shapeContainer1);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox1.Location = new System.Drawing.Point(516, 3);
            this.groupBox1.Name = "groupBox1";
            this.tableLayoutPanel1.SetRowSpan(this.groupBox1, 2);
            this.groupBox1.Size = new System.Drawing.Size(281, 472);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Управление рисованием";
            // 
            // numericUpDownAW
            // 
            this.numericUpDownAW.Location = new System.Drawing.Point(105, 214);
            this.numericUpDownAW.Maximum = new decimal(new int[] {
            8,
            0,
            0,
            0});
            this.numericUpDownAW.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownAW.Name = "numericUpDownAW";
            this.numericUpDownAW.Size = new System.Drawing.Size(35, 20);
            this.numericUpDownAW.TabIndex = 56;
            this.numericUpDownAW.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownAW.ValueChanged += new System.EventHandler(this.numericUpDownAW_ValueChanged);
            // 
            // numericUpDownCW
            // 
            this.numericUpDownCW.Location = new System.Drawing.Point(105, 188);
            this.numericUpDownCW.Maximum = new decimal(new int[] {
            8,
            0,
            0,
            0});
            this.numericUpDownCW.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownCW.Name = "numericUpDownCW";
            this.numericUpDownCW.Size = new System.Drawing.Size(35, 20);
            this.numericUpDownCW.TabIndex = 55;
            this.numericUpDownCW.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownCW.ValueChanged += new System.EventHandler(this.numericUpDownCW_ValueChanged);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label23.Location = new System.Drawing.Point(205, 262);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(45, 13);
            this.label23.TabIndex = 54;
            this.label23.Text = "от края";
            this.label23.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label21.Location = new System.Drawing.Point(47, 321);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(45, 13);
            this.label21.TabIndex = 53;
            this.label21.Text = "График";
            this.label21.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label16.Location = new System.Drawing.Point(73, 28);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(120, 13);
            this.label16.TabIndex = 52;
            this.label16.Text = "Используемый шрифт";
            this.label16.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // checkBoxLineCurve
            // 
            this.checkBoxLineCurve.AutoSize = true;
            this.checkBoxLineCurve.Location = new System.Drawing.Point(21, 359);
            this.checkBoxLineCurve.Name = "checkBoxLineCurve";
            this.checkBoxLineCurve.Size = new System.Drawing.Size(96, 17);
            this.checkBoxLineCurve.TabIndex = 39;
            this.checkBoxLineCurve.Text = "Кривая линия";
            this.checkBoxLineCurve.UseVisualStyleBackColor = true;
            this.checkBoxLineCurve.CheckedChanged += new System.EventHandler(this.checkBoxLineCurve_CheckedChanged);
            // 
            // checkBoxLineBroken
            // 
            this.checkBoxLineBroken.AutoSize = true;
            this.checkBoxLineBroken.Checked = true;
            this.checkBoxLineBroken.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxLineBroken.Location = new System.Drawing.Point(21, 342);
            this.checkBoxLineBroken.Name = "checkBoxLineBroken";
            this.checkBoxLineBroken.Size = new System.Drawing.Size(105, 17);
            this.checkBoxLineBroken.TabIndex = 38;
            this.checkBoxLineBroken.Text = "Ломаная линия";
            this.checkBoxLineBroken.UseVisualStyleBackColor = true;
            this.checkBoxLineBroken.CheckedChanged += new System.EventHandler(this.checkBoxLineBroken_CheckedChanged);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(210, 351);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(32, 13);
            this.label15.TabIndex = 38;
            this.label15.Text = "част.";
            this.label15.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label22.Location = new System.Drawing.Point(47, 247);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(70, 13);
            this.label22.TabIndex = 51;
            this.label22.Text = "Разрешение";
            this.label22.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label20.Location = new System.Drawing.Point(42, 167);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(86, 13);
            this.label20.TabIndex = 49;
            this.label20.Text = "Толщина линий";
            this.label20.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(173, 217);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(34, 13);
            this.label19.TabIndex = 48;
            this.label19.Text = "По Y:";
            this.label19.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(173, 191);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(34, 13);
            this.label3.TabIndex = 47;
            this.label3.Text = "По X:";
            this.label3.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(251, 217);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(16, 13);
            this.label2.TabIndex = 46;
            this.label2.Text = "з.";
            this.label2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // numericUpDownEX2
            // 
            this.numericUpDownEX2.Location = new System.Drawing.Point(212, 214);
            this.numericUpDownEX2.Maximum = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.numericUpDownEX2.Name = "numericUpDownEX2";
            this.numericUpDownEX2.Size = new System.Drawing.Size(37, 20);
            this.numericUpDownEX2.TabIndex = 45;
            this.numericUpDownEX2.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.numericUpDownEX2.ValueChanged += new System.EventHandler(this.numericUpDownEX2_ValueChanged);
            // 
            // buttonRestore
            // 
            this.buttonRestore.Location = new System.Drawing.Point(190, 390);
            this.buttonRestore.Name = "buttonRestore";
            this.buttonRestore.Size = new System.Drawing.Size(72, 56);
            this.buttonRestore.TabIndex = 42;
            this.buttonRestore.Text = "Вернуть начальные значения";
            this.buttonRestore.UseVisualStyleBackColor = true;
            this.buttonRestore.Click += new System.EventHandler(this.buttonRestore_Click);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(97, 421);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(36, 13);
            this.label18.TabIndex = 41;
            this.label18.Text = "Ymax:";
            this.label18.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // textBoxToY
            // 
            this.textBoxToY.Location = new System.Drawing.Point(135, 418);
            this.textBoxToY.Name = "textBoxToY";
            this.textBoxToY.Size = new System.Drawing.Size(48, 20);
            this.textBoxToY.TabIndex = 40;
            // 
            // textBoxFromY
            // 
            this.textBoxFromY.Location = new System.Drawing.Point(45, 418);
            this.textBoxFromY.Name = "textBoxFromY";
            this.textBoxFromY.Size = new System.Drawing.Size(47, 20);
            this.textBoxFromY.TabIndex = 39;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(11, 421);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(33, 13);
            this.label17.TabIndex = 38;
            this.label17.Text = "Ymin:";
            this.label17.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // numericUpDownParts
            // 
            this.numericUpDownParts.Location = new System.Drawing.Point(167, 349);
            this.numericUpDownParts.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numericUpDownParts.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownParts.Name = "numericUpDownParts";
            this.numericUpDownParts.Size = new System.Drawing.Size(37, 20);
            this.numericUpDownParts.TabIndex = 37;
            this.numericUpDownParts.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.numericUpDownParts.ValueChanged += new System.EventHandler(this.numericUpDownParts_ValueChanged);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(160, 333);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(84, 13);
            this.label14.TabIndex = 36;
            this.label14.Text = "Делить оси на:";
            this.label14.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(251, 191);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(16, 13);
            this.label13.TabIndex = 35;
            this.label13.Text = "з.";
            this.label13.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // numericUpDownEX
            // 
            this.numericUpDownEX.Location = new System.Drawing.Point(212, 188);
            this.numericUpDownEX.Maximum = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.numericUpDownEX.Name = "numericUpDownEX";
            this.numericUpDownEX.Size = new System.Drawing.Size(37, 20);
            this.numericUpDownEX.TabIndex = 34;
            this.numericUpDownEX.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.numericUpDownEX.ValueChanged += new System.EventHandler(this.numericUpDownEX_ValueChanged);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label12.Location = new System.Drawing.Point(168, 167);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(99, 13);
            this.label12.TabIndex = 33;
            this.label12.Text = "Точность отметок";
            this.label12.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(233, 287);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(20, 13);
            this.label11.TabIndex = 32;
            this.label11.Text = "pix";
            this.label11.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // numericUpDownShift
            // 
            this.numericUpDownShift.Location = new System.Drawing.Point(191, 284);
            this.numericUpDownShift.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numericUpDownShift.Name = "numericUpDownShift";
            this.numericUpDownShift.Size = new System.Drawing.Size(37, 20);
            this.numericUpDownShift.TabIndex = 31;
            this.numericUpDownShift.Value = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.numericUpDownShift.ValueChanged += new System.EventHandler(this.numericUpDownShift_ValueChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label10.Location = new System.Drawing.Point(185, 248);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(69, 13);
            this.label10.TabIndex = 30;
            this.label10.Text = "Отступ осей";
            this.label10.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(142, 216);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(20, 13);
            this.label9.TabIndex = 29;
            this.label9.Text = "pix";
            this.label9.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(142, 191);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(20, 13);
            this.label1.TabIndex = 28;
            this.label1.Text = "pix";
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(97, 401);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(36, 13);
            this.label8.TabIndex = 24;
            this.label8.Text = "Xmax:";
            this.label8.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(11, 401);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(33, 13);
            this.label7.TabIndex = 23;
            this.label7.Text = "Xmin:";
            this.label7.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // textBoxToX
            // 
            this.textBoxToX.Location = new System.Drawing.Point(135, 398);
            this.textBoxToX.Name = "textBoxToX";
            this.textBoxToX.Size = new System.Drawing.Size(48, 20);
            this.textBoxToX.TabIndex = 22;
            // 
            // textBoxFromX
            // 
            this.textBoxFromX.Location = new System.Drawing.Point(45, 398);
            this.textBoxFromX.Name = "textBoxFromX";
            this.textBoxFromX.Size = new System.Drawing.Size(47, 20);
            this.textBoxFromX.TabIndex = 21;
            // 
            // numericUpDownHeight
            // 
            this.numericUpDownHeight.Enabled = false;
            this.numericUpDownHeight.Location = new System.Drawing.Point(122, 284);
            this.numericUpDownHeight.Maximum = new decimal(new int[] {
            2048,
            0,
            0,
            0});
            this.numericUpDownHeight.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownHeight.Name = "numericUpDownHeight";
            this.numericUpDownHeight.Size = new System.Drawing.Size(45, 20);
            this.numericUpDownHeight.TabIndex = 17;
            this.numericUpDownHeight.Value = new decimal(new int[] {
            768,
            0,
            0,
            0});
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(109, 286);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(12, 13);
            this.label6.TabIndex = 16;
            this.label6.Text = "x";
            this.label6.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // numericUpDownWidth
            // 
            this.numericUpDownWidth.Enabled = false;
            this.numericUpDownWidth.Location = new System.Drawing.Point(62, 284);
            this.numericUpDownWidth.Maximum = new decimal(new int[] {
            2048,
            0,
            0,
            0});
            this.numericUpDownWidth.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownWidth.Name = "numericUpDownWidth";
            this.numericUpDownWidth.Size = new System.Drawing.Size(45, 20);
            this.numericUpDownWidth.TabIndex = 15;
            this.numericUpDownWidth.Value = new decimal(new int[] {
            1024,
            0,
            0,
            0});
            // 
            // checkBoxNotWindowed
            // 
            this.checkBoxNotWindowed.AutoSize = true;
            this.checkBoxNotWindowed.Location = new System.Drawing.Point(12, 286);
            this.checkBoxNotWindowed.Name = "checkBoxNotWindowed";
            this.checkBoxNotWindowed.Size = new System.Drawing.Size(55, 17);
            this.checkBoxNotWindowed.TabIndex = 14;
            this.checkBoxNotWindowed.Text = "Иное:";
            this.checkBoxNotWindowed.UseVisualStyleBackColor = true;
            this.checkBoxNotWindowed.CheckedChanged += new System.EventHandler(this.checkBoxNotWindowed_CheckedChanged);
            // 
            // checkBoxWindowed
            // 
            this.checkBoxWindowed.AutoSize = true;
            this.checkBoxWindowed.Checked = true;
            this.checkBoxWindowed.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxWindowed.Location = new System.Drawing.Point(12, 267);
            this.checkBoxWindowed.Name = "checkBoxWindowed";
            this.checkBoxWindowed.Size = new System.Drawing.Size(116, 17);
            this.checkBoxWindowed.TabIndex = 13;
            this.checkBoxWindowed.Text = "Разрешение окна";
            this.checkBoxWindowed.UseVisualStyleBackColor = true;
            this.checkBoxWindowed.CheckedChanged += new System.EventHandler(this.checkBoxWindowed_CheckedChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(10, 216);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(83, 13);
            this.label5.TabIndex = 11;
            this.label5.Text = "Толщина осей:";
            this.label5.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(9, 191);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(95, 13);
            this.label4.TabIndex = 9;
            this.label4.Text = "Толщина кривой:";
            this.label4.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // buttonChooseFont
            // 
            this.buttonChooseFont.Location = new System.Drawing.Point(188, 47);
            this.buttonChooseFont.Name = "buttonChooseFont";
            this.buttonChooseFont.Size = new System.Drawing.Size(71, 38);
            this.buttonChooseFont.TabIndex = 2;
            this.buttonChooseFont.Text = "Выбрать шрифт...";
            this.buttonChooseFont.UseVisualStyleBackColor = true;
            this.buttonChooseFont.Click += new System.EventHandler(this.buttonChooseFont_Click);
            // 
            // richTextBoxFontTest
            // 
            this.richTextBoxFontTest.Location = new System.Drawing.Point(12, 47);
            this.richTextBoxFontTest.Name = "richTextBoxFontTest";
            this.richTextBoxFontTest.ReadOnly = true;
            this.richTextBoxFontTest.Size = new System.Drawing.Size(170, 38);
            this.richTextBoxFontTest.TabIndex = 1;
            this.richTextBoxFontTest.Text = "1 2.3 Образец шрифта";
            // 
            // shapeContainer1
            // 
            this.shapeContainer1.Location = new System.Drawing.Point(3, 16);
            this.shapeContainer1.Margin = new System.Windows.Forms.Padding(0);
            this.shapeContainer1.Name = "shapeContainer1";
            this.shapeContainer1.Shapes.AddRange(new Microsoft.VisualBasic.PowerPacks.Shape[] {
            this.lineShape9,
            this.lineShape8,
            this.lineShape7,
            this.lineShape6,
            this.lineShape5,
            this.lineShape4,
            this.lineShape2,
            this.lineShape3,
            this.lineShape1});
            this.shapeContainer1.Size = new System.Drawing.Size(275, 453);
            this.shapeContainer1.TabIndex = 44;
            this.shapeContainer1.TabStop = false;
            // 
            // lineShape9
            // 
            this.lineShape9.Name = "lineShape9";
            this.lineShape9.X1 = 10;
            this.lineShape9.X2 = 257;
            this.lineShape9.Y1 = 5;
            this.lineShape9.Y2 = 5;
            // 
            // lineShape8
            // 
            this.lineShape8.Name = "lineShape8";
            this.lineShape8.X1 = 9;
            this.lineShape8.X2 = 256;
            this.lineShape8.Y1 = 78;
            this.lineShape8.Y2 = 78;
            // 
            // lineShape7
            // 
            this.lineShape7.Name = "lineShape7";
            this.lineShape7.X1 = 138;
            this.lineShape7.X2 = 138;
            this.lineShape7.Y1 = 297;
            this.lineShape7.Y2 = 367;
            // 
            // lineShape6
            // 
            this.lineShape6.Name = "lineShape6";
            this.lineShape6.X1 = 7;
            this.lineShape6.X2 = 254;
            this.lineShape6.Y1 = 368;
            this.lineShape6.Y2 = 368;
            // 
            // lineShape5
            // 
            this.lineShape5.Name = "lineShape5";
            this.lineShape5.X1 = 7;
            this.lineShape5.X2 = 254;
            this.lineShape5.Y1 = 297;
            this.lineShape5.Y2 = 297;
            // 
            // lineShape4
            // 
            this.lineShape4.Name = "lineShape4";
            this.lineShape4.X1 = 174;
            this.lineShape4.X2 = 174;
            this.lineShape4.Y1 = 223;
            this.lineShape4.Y2 = 296;
            // 
            // lineShape2
            // 
            this.lineShape2.Name = "lineShape2";
            this.lineShape2.X1 = 7;
            this.lineShape2.X2 = 254;
            this.lineShape2.Y1 = 223;
            this.lineShape2.Y2 = 223;
            // 
            // lineShape3
            // 
            this.lineShape3.Name = "lineShape3";
            this.lineShape3.X1 = 8;
            this.lineShape3.X2 = 255;
            this.lineShape3.Y1 = 144;
            this.lineShape3.Y2 = 144;
            // 
            // lineShape1
            // 
            this.lineShape1.Name = "lineShape1";
            this.lineShape1.X1 = 161;
            this.lineShape1.X2 = 161;
            this.lineShape1.Y1 = 145;
            this.lineShape1.Y2 = 223;
            // 
            // panel
            // 
            this.panel.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel.Controls.Add(this.pictureBoxWindow);
            this.panel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel.Location = new System.Drawing.Point(3, 3);
            this.panel.Name = "panel";
            this.panel.Size = new System.Drawing.Size(507, 437);
            this.panel.TabIndex = 3;
            // 
            // pictureBoxWindow
            // 
            this.pictureBoxWindow.Cursor = System.Windows.Forms.Cursors.Cross;
            this.pictureBoxWindow.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBoxWindow.Location = new System.Drawing.Point(0, 0);
            this.pictureBoxWindow.Name = "pictureBoxWindow";
            this.pictureBoxWindow.Size = new System.Drawing.Size(507, 437);
            this.pictureBoxWindow.TabIndex = 4;
            this.pictureBoxWindow.TabStop = false;
            this.pictureBoxWindow.Paint += new System.Windows.Forms.PaintEventHandler(this.pictureBoxWindow_Paint);
            this.pictureBoxWindow.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBoxWindow_MouseDown);
            this.pictureBoxWindow.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pictureBoxWindow_MouseMove);
            this.pictureBoxWindow.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pictureBoxWindow_MouseUp);
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.AutoSize = true;
            this.flowLayoutPanel1.Controls.Add(this.buttonGraphToFile);
            this.flowLayoutPanel1.Controls.Add(this.buttonGraph);
            this.flowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel1.FlowDirection = System.Windows.Forms.FlowDirection.RightToLeft;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(3, 446);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(507, 29);
            this.flowLayoutPanel1.TabIndex = 0;
            // 
            // buttonGraphToFile
            // 
            this.buttonGraphToFile.Location = new System.Drawing.Point(356, 3);
            this.buttonGraphToFile.Name = "buttonGraphToFile";
            this.buttonGraphToFile.Size = new System.Drawing.Size(148, 25);
            this.buttonGraphToFile.TabIndex = 43;
            this.buttonGraphToFile.Text = "Сохранить в файл...";
            this.buttonGraphToFile.UseVisualStyleBackColor = true;
            this.buttonGraphToFile.Click += new System.EventHandler(this.buttonGraphToFile_Click);
            // 
            // buttonGraph
            // 
            this.buttonGraph.BackColor = System.Drawing.SystemColors.Highlight;
            this.buttonGraph.Location = new System.Drawing.Point(186, 3);
            this.buttonGraph.Name = "buttonGraph";
            this.buttonGraph.Size = new System.Drawing.Size(164, 25);
            this.buttonGraph.TabIndex = 42;
            this.buttonGraph.Text = "Строить график";
            this.buttonGraph.UseVisualStyleBackColor = false;
            this.buttonGraph.Click += new System.EventHandler(this.buttonGraph_Click);
            // 
            // multiGrapherPens1
            // 
            this.multiGrapherPens1.Location = new System.Drawing.Point(6, 98);
            this.multiGrapherPens1.Name = "multiGrapherPens1";
            this.multiGrapherPens1.Size = new System.Drawing.Size(255, 60);
            this.multiGrapherPens1.TabIndex = 43;
            // 
            // GraphicDrawer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.statusStrip);
            this.MinimumSize = new System.Drawing.Size(800, 500);
            this.Name = "GraphicDrawer";
            this.Size = new System.Drawing.Size(800, 500);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.GraphicDrawer_KeyDown);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.GraphicDrawer_KeyUp);
            this.Resize += new System.EventHandler(this.GraphicDrawer_Resize);
            this.ParentChanged += new System.EventHandler(this.GraphicDrawer_ParentChanged);
            this.statusStrip.ResumeLayout(false);
            this.statusStrip.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownAW)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownCW)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownEX2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownParts)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownEX)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownShift)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownHeight)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownWidth)).EndInit();
            this.panel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxWindow)).EndInit();
            this.flowLayoutPanel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.FontDialog fontDialogForGrapher;
        private System.Windows.Forms.ColorDialog colorDialogForGrapher;
        private System.Windows.Forms.SaveFileDialog saveFileDialog;
        private System.Windows.Forms.StatusStrip statusStrip;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabelCoord;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.CheckBox checkBoxLineCurve;
        private System.Windows.Forms.CheckBox checkBoxLineBroken;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.NumericUpDown numericUpDownEX2;
        private Components.MultiGrapherPens multiGrapherPens1;
        private System.Windows.Forms.Button buttonRestore;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox textBoxToY;
        private System.Windows.Forms.TextBox textBoxFromY;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.NumericUpDown numericUpDownParts;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.NumericUpDown numericUpDownEX;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.NumericUpDown numericUpDownShift;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBoxToX;
        private System.Windows.Forms.TextBox textBoxFromX;
        private System.Windows.Forms.NumericUpDown numericUpDownHeight;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.NumericUpDown numericUpDownWidth;
        private System.Windows.Forms.CheckBox checkBoxNotWindowed;
        private System.Windows.Forms.CheckBox checkBoxWindowed;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button buttonChooseFont;
        private System.Windows.Forms.RichTextBox richTextBoxFontTest;
        private Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer1;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape9;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape8;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape7;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape6;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape5;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape4;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape2;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape3;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape1;
        private System.Windows.Forms.Panel panel;
        private System.Windows.Forms.PictureBox pictureBoxWindow;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Button buttonGraphToFile;
        private System.Windows.Forms.Button buttonGraph;
        private System.Windows.Forms.NumericUpDown numericUpDownAW;
        private System.Windows.Forms.NumericUpDown numericUpDownCW;
    }
}