﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using whiteMath.ArithmeticLong;

namespace whiteMath.Calculators
{
    /// <summary>
    /// The default calculator for whiteMath long integer numbers.
    /// </summary>
    public class CalcLongInt: ICalc<LongInt>
    {
        public LongInt sum(LongInt one, LongInt two) { return one + two; }
        public LongInt dif(LongInt one, LongInt two) { return one - two; }
        public LongInt mul(LongInt one, LongInt two) { return one * two; }
        public LongInt div(LongInt one, LongInt two) { return one / two; }
        public LongInt rem(LongInt one, LongInt two) { return one % two; }

        public LongInt negate(LongInt num) { return -num; }

        public bool mor(LongInt one, LongInt two) { return one > two; }
        public bool eqv(LongInt one, LongInt two) { return one == two; }

        public bool isNaN(LongInt num) { return false; }
        public bool isPosInf(LongInt num) { return false; }
        public bool isNegInf(LongInt num) { return false; }

        public LongInt getCopy(LongInt num) { return num.Clone() as LongInt; }
        public LongInt zero { get { return new LongInt(); } }

        public LongInt fromInt(int equivalent) { return new LongInt(equivalent); }
        public LongInt fromDouble(double equivalent) { return new LongInt((long)equivalent); }
    }
}
