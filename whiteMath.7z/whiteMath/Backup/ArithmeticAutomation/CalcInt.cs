﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace whiteMath.Calculators
{
    /// <summary>
    /// Standard calculator for integers.
    /// </summary>
    public class CalcInt : ICalc<int>
    {
        public int sum(int one, int two) { return one + two; }
        public int dif(int one, int two) { return one - two; }
        public int mul(int one, int two) { return one * two; }
        public int div(int one, int two) { return one / two; }
        public int rem(int one, int two) { return one % two; }

        public bool mor(int one, int two) { return one > two; }
        public bool eqv(int one, int two) { return one == two; }

        public int negate(int one) { return -one; }

        public bool isNaN(int one) { return false; }
        public bool isPosInf(int one) { return false; }
        public bool isNegInf(int one) { return false; }

        public int getCopy(int val) { return val; }
        public int zero { get { return 0; } }

        public int fromInt(int equivalent) { return equivalent; }
        public int fromDouble(double equivalent) { return (int)equivalent; }
    }
}
