﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace whiteMath
{
    /// <summary>
    /// An interface used for different numeric calculating purposes.
    /// Provides an abstraction for Numeric(T,C) generic class to overload
    /// operators, get default values etc.
    /// 
    /// If a calculator for a type is made correctly, one can perform "arithmetic" operations
    /// with type instances as if they were primitive numbers.
    /// </summary>
    public interface ICalc<T>
    {
        T sum(T one, T two);        // calculates a sum of two numbers
        T dif(T one, T two);        // calculates the difference in numbers
        T mul(T one, T two);        // multiplies one number by another
        T div(T one, T two);        // divides one number by another
        T rem(T one, T two);        // returns the remainder of division (only for integers)

        T negate(T one);            // negates a number

        bool mor(T one, T two);     // checks if the first number is more than the second
        bool eqv(T one, T two);     // checks whether two numbers are equal

        bool isNaN(T one);          // checks whether a number is infinity
        bool isPosInf(T one);       // checks whether a number is a positive infinity
        bool isNegInf(T one);       // checks whether a number is a negative infinity

        T getCopy(T source);        // returns a copy of a particular number

        T fromInt(int equivalent);          // returns a T equivalent to the specified int number (required by Math algorithms)
        T fromDouble(double equivalent);    // returns a T equivalent to the specified double number (required by Math algorithms)
        T zero { get; }             // returns a "zero" value of T type
    }
}
