﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace whiteMath
{
    public struct Numeric<T, C> where C:ICalc<T>, new()
    {
        private T value;                     // the value within the number
        private static C calc = new C();     // the calculator used with numbers

        private Numeric(T value)
        {
            this.value = value;
        }

        // --------------------------------------
        // --------------------------------------
        // --------------------------------------

        /// <summary>
        /// Gets a deep copy of current number.
        /// </summary>
        public Numeric<T, C> Copy { get { return calc.getCopy(this); } }

        /// <summary>
        /// Gets a zero number for T type.
        /// </summary>
        public static Numeric<T, C> Zero { get { return calc.zero; } }

        // --------------------------------------
        // ---------CONVERSION OPERATORS---------
        // --------------------------------------

        public static implicit operator Numeric<T, C>(T val)
        {
            return new Numeric<T, C>(val);
        }

        public static implicit operator T(Numeric<T, C> obj)
        {
            return obj.value;
        }

        // --------------------------------------
        // --------------------------------------
        // --------------------------------------

        public static Numeric<T, C> operator +(Numeric<T, C> one, Numeric<T, C> two)
        {
            return calc.sum(one, two);
        }

        public static Numeric<T, C> operator -(Numeric<T, C> one, Numeric<T, C> two)
        {
            return calc.dif(one, two);
        }

        public static Numeric<T, C> operator *(Numeric<T, C> one, Numeric<T, C> two)
        {
            return calc.mul(one, two);
        }

        public static Numeric<T, C> operator /(Numeric<T, C> one, Numeric<T, C> two)
        {
            return calc.div(one, two);
        }

        public static Numeric<T, C> operator -(Numeric<T, C> one)
        {
            return calc.negate(one);
        }

        // --------------------------------------
        // ---------------- NaN and Infinities checking
        // --------------------------------------

        public static bool isNaN(Numeric<T, C> one)
        {
            return calc.isNaN(one);
        }

        public static bool isPositiveInfinity(Numeric<T, C> one)
        {
            return calc.isPosInf(one);
        }

        public static bool isNegativeInfinity(Numeric<T, C> one)
        {
            return calc.isNegInf(one);
        }

        public static bool isInfinity(Numeric<T, C> one)
        {
            return calc.isPosInf(one) || calc.isNegInf(one);
        }

        // --------------------------------------
        // ---------------- Comparison operators
        // --------------------------------------

        public static bool operator >(Numeric<T, C> one, Numeric<T, C> two)
        {
            return calc.mor(one, two);
            // directly
        }

        public static bool operator <(Numeric<T, C> one, Numeric<T, C> two)
        {
            return calc.mor(two, one);
            // a<b <==> b>a
        }

        public static bool operator ==(Numeric<T, C> one, Numeric<T, C> two)
        {
            return calc.eqv(one, two);
            // directly
        }

        public static bool operator !=(Numeric<T, C> one, Numeric<T, C> two)
        {
            return !calc.eqv(one, two);
            // a!=b  <==> !(a==b)
        }

        public static bool operator >=(Numeric<T, C> one, Numeric<T, C> two)
        {
            return !calc.mor(two, one);
            // a>=b  <==> !(b>a)
        }

        public static bool operator <=(Numeric<T, C> one, Numeric<T, C> two)
        {
            return !calc.mor(one, two);
            // a<=b  <==> !(a>b)
        }

        // Equals, hashcode and toString

        /// <summary>
        /// Checks whether 
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        public override bool Equals(object obj)
        {
            if (obj is T)
                return (this.value.Equals(obj));
            else if (obj is Numeric<T,C>)
                return (this.value.Equals(((Numeric<T,C>)obj).value));
            
            return false;
        }

        /// <summary>
        /// Returns the hash code of the value stored.
        /// </summary>
        /// <returns>The hash code of the value stored.</returns>
        public override int GetHashCode()
        {
            return value.GetHashCode();
        }

        /// <summary>
        /// Returns the standard string representation of the value stored.
        /// </summary>
        /// <returns>The string representation of the value stored.</returns>
        public override string ToString()
        {
            return value.ToString();
        }
    }
}
