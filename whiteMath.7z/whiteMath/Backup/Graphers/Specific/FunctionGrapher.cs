﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using whiteMath.Functions;

namespace whiteMath.Graphers
{
    public class FunctionGrapher: AbstractGrapher
    {
        IFunction<double, double> function;
        int dotCount=100; // количество точек для построения

        /// <summary>
        /// How many points to calculate in the mentioned diap.
        /// Graphing quality depends on it. Usually 1000 is enough.
        /// </summary>
        public int DotCount { get { return dotCount; } set { if (value > 2) dotCount = value; } }

        public FunctionGrapher(IFunction<double,double> function)
        {
            if (function != null) this.function = function;
            else
                throw new GrapherSettingsException("Невозможно создать объект FunctionGrapher: переданная ссылка функции является ссылкой на null!");
        }

        public override void Graph(System.Drawing.Image destinationImage, GraphingArgs graphingArgs, double xMin, double xMax)
        {
            if (xMin >= xMax) throw new GrapherGraphException("Диапазоны должны задаваться от меньшего числа к большему.");

            double step = (xMax - xMin) / (dotCount - 1);
            double yMin, yMax;

            double[][] pointsArray = GetPointsArraySkeleton(step, xMin, xMax, out yMin, out yMax);
            GraphSkeleton(destinationImage, graphingArgs, xMin, xMax, yMin, yMax, pointsArray);
        }

        public override void Graph(System.Drawing.Image destinationImage, GraphingArgs graphingArgs, double xMin, double xMax, double yMin, double yMax)
        {
            if (xMin >= xMax || yMin >= yMax) throw new GrapherGraphException("Диапазоны должны задаваться от меньшего числа к большему.");

            double step = (xMax - xMin) / (dotCount - 1);
            double dummy;
            double[][] pointsArray = GetPointsArraySkeleton(step, xMin, xMax, out dummy, out dummy);

            GraphSkeleton(destinationImage, graphingArgs, xMin, xMax, yMin, yMax, pointsArray);
        }

        private void GraphSkeleton(System.Drawing.Image destinationImage, GraphingArgs graphingArgs, double xMin, double xMax, double yMin, double yMax, double[][] pointsArray)
        {
            ArrayGrapher tmp = new ArrayGrapher(pointsArray);
            copyGrapherSignature(this, tmp);

            tmp.Graph(destinationImage, graphingArgs, xMin, xMax, yMin, yMax);
        }

        private double[][] GetPointsArraySkeleton(double step, double xMin, double xMax, out double yMin, out double yMax)
        {
            try
            {
                yMin = double.PositiveInfinity;
                yMax = double.NegativeInfinity;

                List<double[]> temPoints = new List<double[]>();
                double ytw=double.NaN; // значение функции в указанной точке
                double yprev; // предыдущее значение функции

                for (double x = xMin; x < xMax; x += step)
                {
                    yprev = ytw;
                    ytw = function[x];

                    // около границ области определения должна многократно повышаться точность.
                    // пока что повышается стократно
                    if (step/100 > 0)
                        if (( !ytw.IsNormalNumber() && yprev.IsNormalNumber())
                            || (!yprev.IsNormalNumber() && ytw.IsNormalNumber()))
                            {
                                double ytmp;
                                for (double xtmp = x - step + step / 100; xtmp < x; xtmp += step / 100)
                                {
                                    ytmp = function[xtmp];
                                    if (ytmp < yMin) yMin = ytmp;
                                    else if (ytmp > yMax) yMax = ytmp;
                                    temPoints.Add(new double[2] { xtmp, ytmp });
                                }
                        }
                    temPoints.Add(new double[2] { x, ytw }) ;
                    if (ytw < yMin) yMin = ytw;
                    else if (ytw > yMax) yMax = ytw;
                }

                // с учетом погрешности последнюю точку добавляем особливо
                temPoints.Add(new double[2] { xMax, function[xMax] });

                return temPoints.ToArray();
            }
            catch { throw; }
        }

    }

    public static class DoubleExtensionMethods
    {
        public static bool IsNormalNumber(this double a)
        {
            return (!double.IsNaN(a) && !double.IsInfinity(a));
        }
    }
}
