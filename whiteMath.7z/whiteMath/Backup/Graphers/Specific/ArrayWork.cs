﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Text;

// предоставляет интерфейс-наследник IComparer для сортировки считанного массива точек.

namespace whiteMath.Graphers.Services
{
    internal class DotListComparer<T>: Comparer<double[]>
    {
        public override int Compare(double[] a, double[] b)
        {
            if (a == null) return (b == null ? 0 : 1);
            if (b == null) return (a == null ? 0 : 1);

            if (a[0] > b[0]) return 1;
            else if (a[0] < b[0]) return -1;
            else if (a[0] == b[0]) return 0;
            return 0;
        }
    }

    public static class GrapherArrayWork
    {
        public static double Max(double[] arr)
        {
            if (arr==null || arr.Length == 0) return 0;
            double Max=arr[0];
            foreach (double a in arr)
                if (a > Max) Max = a;
            return Max;
        }
        
        internal static void DoublePointSort(double[][] pointsArray)
        {
            for (int i = 0; i < pointsArray.Length; i++)
                if (pointsArray[i].Length != 2) throw new Exception("Метод предназначен только для сортировки массива точек, длина каждого Double[] элемента должна быть равна двум (2 координаты).");

            Comparison<double[]> comp = new DotListComparer<double[]>().Compare; 
            Array.Sort<double[]>(pointsArray, comp);      
        }

        internal static double CheckForCastInfinities(double[][] pointsArray) // метод возвращает число, на которое нужно поделить все, чтобы уложить в диапазон float
        {
            double divider = 1;
            for(int i=0; i<pointsArray.Length; i++)
            {
                if (!double.IsInfinity(pointsArray[i][0]) && pointsArray[i][0] < float.MinValue)
                {
                    double tmp = pointsArray[i][0] / float.MinValue;
                    if (tmp > divider) divider = tmp;
                }
                if (!double.IsInfinity(pointsArray[i][0]) && pointsArray[i][0] > float.MaxValue)
                {
                    double tmp = pointsArray[i][0] / float.MaxValue;
                    if (tmp > divider) divider = tmp;
                }
                if (!double.IsInfinity(pointsArray[i][1]) && pointsArray[i][1] < float.MinValue)
                {
                    double tmp = pointsArray[i][1] / float.MinValue;
                    if (tmp > divider) divider = tmp;
                }
                if (!double.IsInfinity(pointsArray[i][1]) && pointsArray[i][1] > float.MaxValue)
                {
                    double tmp = pointsArray[i][1] / float.MaxValue;
                    if (tmp > divider) divider = tmp;
                }
            }

            return divider;
        }
    }

}
