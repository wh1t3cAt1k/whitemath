﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace whiteMath.Graphers
{
    // ----------- EXCEPTIONS для графера

    public class GrapherException : Exception
    { public GrapherException(string message) : base(message) { } }

    public class GrapherGraphException: GrapherException
    {
        public GrapherGraphException(string message) : base(message) { }

        public override string Message
        {
            get
            {
                return "Ошибка построения графика зависимости. "+base.Message;
            }
        }
    }

    public class GrapherActionImpossibleException : GrapherException
    {
        public GrapherActionImpossibleException(string message) : base(message) { }

        public override string Message
        {
            get
            {
                return base.Message+" Дальнейшее выполнение действия невозможно.";
            }
        }
    }

    public class GrapherSettingsException : GrapherException
    {
        public GrapherSettingsException(string message) : base(message) { }

        public override string Message
        {
            get
            {
                return "Ошибка задания свойств графера. "+base.Message;
            }
        }
    }

}
