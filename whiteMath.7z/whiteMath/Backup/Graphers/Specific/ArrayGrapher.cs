﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Text;

using whiteMath.Graphers.Services;

namespace whiteMath.Graphers
{
    public class ArrayGrapher: StandardGrapher
    {
        public ArrayGrapher(Double[][] PointsArray)
        {
            GrapherArrayWork.DoublePointSort(PointsArray);
            
            this.PointsArray = PointsArray;
            
            SortPointsArray();
            FindMaximumsAndMinimums();
        }

        public ArrayGrapher(Double[] xArray, Double[] yArray)
        {
            if (xArray.Length!=yArray.Length)
                throw new Exception("The length of the X coordinate array equals "+
                    xArray.Length+" and is not equal to the length of the Y coordinate array: "
                    +yArray.Length);
            if (xArray.Length == 0) throw new Exception("The length of the X coordinate array equals zero.");
            if (yArray.Length == 0) throw new Exception("The length of the Y coordinate array equals zero.");
 
            double[][] tempArray = new double[xArray.Length][];
            for(int i=0; i < tempArray.Length; i++)
             tempArray[i] = new Double[] { xArray[i], yArray[i] };
            GrapherArrayWork.DoublePointSort(tempArray);

            this.PointsArray = tempArray;
            
            SortPointsArray();
            FindMaximumsAndMinimums();
        }
    }
}
