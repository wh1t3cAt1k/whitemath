﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;

namespace whiteMath.Graphers
{
    /// <summary>
    /// The enumeration used to specify the line type for GraphingArgs class.
    /// </summary>
    public enum LineType
    {
        Line,
        CardinalCurve,
        Polygon
    }

    /// <summary>
    /// Revised: 20.01.2010
    /// Author: Pavel Kabir
    /// Version: 1.0
    /// </summary>
    public sealed class GraphingArgs
    {
        public int indentFromImageBounds { get; set; }
        public Pen curvePen { get; set; }
        public Pen coordPen { get; set; }
        public Pen gridPen { get; set; }
        
        public Font coordFont { get; set; } 
        public LineType curveType { get; set; }
        
        public bool drawAxis { get; set; }
        public bool drawNumbers { get; set; }
        public bool drawGrid { get; set; }

        public GraphingArgs(int indentFromImageBounds, Pen curvePen, Pen coordPen, Pen gridPen,
            Font coordFont, LineType curveType, bool drawAxis, bool drawNumbers, bool drawGrid)
        {
            if (indentFromImageBounds < 0) indentFromImageBounds = 0;
            if (curvePen == null) throw new NullReferenceException("curvePens is a null reference.");
            if (coordPen == null) throw new NullReferenceException("coordPens is a null reference.");
            if (gridPen == null) throw new NullReferenceException("gridPens is a null reference.");
            if (coordFont == null) throw new NullReferenceException("coordFonts is a null reference.");

            this.indentFromImageBounds = indentFromImageBounds;
            
            this.curvePen = curvePen;
            this.coordPen = coordPen;
            this.gridPen = gridPen;
            
            this.coordFont = coordFont;
            this.curveType = curveType;

            this.drawAxis = drawAxis;
            this.drawNumbers = drawNumbers;
            this.drawGrid = drawGrid;
        }

        /// <summary>
        /// Checks if the graphing args object is correctly formed.
        /// If some of the graphing args are null - returns false.
        /// </summary>
        /// <returns>Boolean value. "True" guarantees correct graphing.</returns>
        public bool Check()
        {
            if (curvePen == null || coordPen == null || (drawGrid == true && gridPen == null)
                || coordFont == null) return false;
            return true;
        }
    }
}
