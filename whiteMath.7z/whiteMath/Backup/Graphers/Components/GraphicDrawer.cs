﻿using System;
using whiteMath.Graphers;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Collections;
using System.Text;
using System.IO;
using System.Windows.Forms;

namespace whiteMath.Graphers
{
    /// <summary>
    /// Windows form for drawing graphs using Grapher objects.
    /// Suitable for bounded and unbounded graphers.
    /// 
    /// author: Pavel Kabir
    /// revised: 21.01.2010
    /// version: 1.1
    /// </summary>
    public partial class GraphicDrawer : Form
    {
        CoordinateTransformer ctf = new CoordinateTransformer();
        AbstractGrapher G;  // the grapher object
        
        Image shownImage;   // an image that is fully or partially shown

        int xImageCoordinate=0;            // coordinates of image to draw
        int yImageCoordinate=0;            //

                            // диапазон рисования
        double xMin;
        double xMax;
        double yMin;
        double yMax;
                            //--------------------

        // ----------------- service values

        bool somethingIsDrawn = false;
        
        // ----------------- graphing parameters
        
        Color CurveColor = Color.DarkBlue;
        Color AxisColor = Color.Black;
        Font CoordFont = SystemFonts.SmallCaptionFont;
        LineType LT = LineType.Line;

        // Events

        public event GraphicDrawerGraphClickEventHandler GraphicDrawerGraphClick;

        //  ------------- КОНСТРУКТОРЫ

        public GraphicDrawer(StandardGrapher obj):
            this(obj, obj.MinAxis1, obj.MaxAxis1, obj.MinAxis2, obj.MaxAxis2) {}

        public GraphicDrawer(AbstractGrapher grapher, double xMin, double xMax, double yMin, double yMax)
        {
            InitializeComponent();
            G = grapher;

            LT = LineType.CardinalCurve;

            if(typeof(AbstractGrapher).IsInstanceOfType(grapher)) labelObjName.Text = ((AbstractGrapher)grapher).Name;
           
            pictureBoxWindow.SizeMode = PictureBoxSizeMode.Normal;
            pictureBoxWindow.Image = new Bitmap(pictureBoxWindow.Width, pictureBoxWindow.Height);

            pictureBoxWindow.MouseMove += new MouseEventHandler(
                delegate(object source, MouseEventArgs e)
                {
                    if(somethingIsDrawn)
                        toolStripStatusLabelCoord.Text = String.Format("X={0}, Y={1}", ctf.transformImageXtoFunctionX(this.xImageCoordinate + e.X), ctf.transformImageYToFunctionY(this.yImageCoordinate + e.Y));
                });

            pictureBoxWindow.MouseClick += new MouseEventHandler(
                delegate(object source, MouseEventArgs e)
                {
                    if (e.Button == MouseButtons.Left) return;

                    if (somethingIsDrawn && GraphicDrawerGraphClick != null)
                    {
                        double x = ctf.transformImageXtoFunctionX(this.xImageCoordinate + e.X);
                        double y = ctf.transformImageYToFunctionY(this.yImageCoordinate + e.Y);
                        GraphicDrawerGraphClick.Invoke(this, new GraphicDrawerGraphClickEventArgs(e.X, e.Y, x, y));
                    }
                });

            richTextBoxFontTest.Font = CoordFont;
            textBoxCC.BackColor = CurveColor;
            textBoxAC.BackColor = AxisColor;

            this.xMin = xMin;
            this.xMax = xMax;
            this.yMin = yMin;
            this.yMax = yMax;

            buttonRestore_Click(this, EventArgs.Empty);
        }

        private void checkBoxWindowed_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBoxWindowed.Checked)
            {
                checkBoxNotWindowed.Checked = false;
                numericUpDownHeight.Enabled = numericUpDownWidth.Enabled = false;
            }
            else 
            {
                checkBoxNotWindowed.Checked = true;
                numericUpDownHeight.Enabled = numericUpDownWidth.Enabled = true;
                numericUpDownWidth.Value = 1024;
                numericUpDownHeight.Value = 768;
            }
        }

        /// <summary>
        /// Восстанавливает умолчания по границам рисования
        /// и перерисовывает график.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonRestore_Click(object sender, EventArgs e)
        {
            textBoxFromX.Text = xMin.ToString();
            textBoxFromY.Text = yMin.ToString();
            textBoxToX.Text = xMax.ToString();
            textBoxToY.Text = yMax.ToString();

            buttonGraph_Click(this, EventArgs.Empty);
        }

        /// <summary>
        /// Проверка, указал ли пользователь иное разрешение,
        /// чем разрешение рабочего окна.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void checkBoxNotWindowed_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBoxNotWindowed.Checked)
                checkBoxWindowed.Checked = false;
            else checkBoxWindowed.Checked = true;
        }


        private void buttonChooseFont_Click(object sender, EventArgs e)
        {
            if(fontDialogForGrapher.ShowDialog()==DialogResult.OK)
             CoordFont = fontDialogForGrapher.Font;
            richTextBoxFontTest.Font = CoordFont;
        }

        private void buttonChooseCC_Click(object sender, EventArgs e)
        {
            if (colorDialogForGrapher.ShowDialog() == DialogResult.OK)
                CurveColor = colorDialogForGrapher.Color;
            textBoxCC.BackColor = CurveColor;
        }

        private void buttonChooseAC_Click(object sender, EventArgs e)
        {
            if (colorDialogForGrapher.ShowDialog() == DialogResult.OK)
                AxisColor = colorDialogForGrapher.Color;
            textBoxAC.BackColor = AxisColor;
        }

        private void buttonGraph_Click(object sender, EventArgs e)
        {
            this.somethingIsDrawn = false;      // reset the bool value to false.

            float CW, AW;
            
            if(!float.TryParse(textBoxCW.Text, out CW))
                {
                    MessageBox.Show(this, "Невозможно определить значение толщины кривой. Проверьте правильность ввода.", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    textBoxCW.Clear();
                    textBoxCW.Focus();
                    return;
                }
            if (!float.TryParse(textBoxAW.Text, out AW))
            {
                MessageBox.Show(this, "Невозможно определить значение толщины линий осей. Проверьте правильность ввода.", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                textBoxAW.Clear();
                textBoxAW.Focus();
                return;
            }

              Pen CurvePen = new Pen(new SolidBrush(CurveColor), CW);
              Pen CoordPen = new Pen(new SolidBrush(AxisColor), AW);

              if (checkBoxNotWindowed.Checked)
                  shownImage = new Bitmap((int)numericUpDownWidth.Value, (int)numericUpDownHeight.Value);
              else
                  shownImage = new Bitmap(pictureBoxWindow.Width, pictureBoxWindow.Height);

            // --------- Работа с масштабированием

            double xMinNew=0, xMaxNew=0;
            double yMinNew=0, yMaxNew=0;

            #region CheckingTextboxValidating

            if (!double.TryParse(textBoxFromX.Text, out xMinNew))
                {
                    MessageBox.Show(this, "Невозможно определить значение нижней границы масштабирования. Проверьте правильность ввода.", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    textBoxFromX.Clear();
                    textBoxFromX.Focus();
                    return;
                }
            if (!double.TryParse(textBoxToX.Text, out xMaxNew))
                {
                    MessageBox.Show(this, "Невозможно определить значение верхней границы масштабирования. Проверьте правильность ввода.", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    textBoxToX.Clear();
                    textBoxToX.Focus();
                    return;
                }
            if (!double.TryParse(textBoxFromY.Text, out yMinNew))
            {
                    MessageBox.Show(this, "Невозможно определить значение нижней границы масштабирования. Проверьте правильность ввода.", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    textBoxFromY.Clear();
                    textBoxFromY.Focus();
                    return;
            }
            if (!double.TryParse(textBoxToY.Text, out yMaxNew))
            {
                    MessageBox.Show(this, "Невозможно определить значение верхней границы масштабирования. Проверьте правильность ввода.", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    textBoxToY.Clear();
                    textBoxToY.Focus();
                    return;
            }

            // --------- Назначаем шаг

            if (yMax != yMin && !double.IsNaN(yMax) && !double.IsInfinity(yMin))
            {
                G.Axis1CoordinateStep = (xMaxNew - xMinNew) / (int)numericUpDownParts.Value;
                G.Axis2CoordinateStep = (yMaxNew - yMinNew) / (int)numericUpDownParts.Value;
            }

            #endregion

            string formatter = "{0:G";
            formatter+=numericUpDownEX.Value.ToString()+"}";

            G.Axis1NumbersFormatter = G.Axis2NumbersFormatter = formatter;

            try
            {
                GraphingArgs graphingArgs = new GraphingArgs((int)numericUpDownShift.Value, CurvePen , CoordPen, Pens.LightGray, CoordFont, LT, true, true, true);
                
                Graphics g = Graphics.FromImage(shownImage);
                g.FillRectangle(Brushes.White, 0, 0, shownImage.Width, shownImage.Height);
                
                G.Graph(shownImage, graphingArgs, xMinNew, xMaxNew, yMinNew, yMaxNew);
                
                // ---- re-initialize the transformer

                ctf.setGraphingRange(xMinNew, xMaxNew, yMinNew, yMaxNew);
                ctf.setImageSize(shownImage.Size);
                ctf.setImageBorderIndent((int)numericUpDownShift.Value);

                // ------------------------------------

                if (shownImage.Width <= pictureBoxWindow.Width && shownImage.Height <= pictureBoxWindow.Height)
                     pictureBoxWindow.Image = shownImage;
                else ShowImageInPictureBox(); 
            }
            catch (GrapherException ex)
            {
                MessageBox.Show(this, "Не удалось построить график: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            CurvePen.Dispose();
            CoordPen.Dispose();
            this.somethingIsDrawn = true;       // set the value to true.
        }

        /// <summary>
        /// Показывает кусочек каринки в pictureBox с учетом текущих координат.
        /// </summary>
        private void ShowImageInPictureBox()
        {
            int w = pictureBoxWindow.Width;
            int h = pictureBoxWindow.Height;
            pictureBoxWindow.Image = new Bitmap(w, h);
            Graphics tmp = Graphics.FromImage(pictureBoxWindow.Image);

            // ---- Тут позже предусмотреть перемещение по всей координатной системе

            if (xImageCoordinate > shownImage.Width - w)
                xImageCoordinate = shownImage.Width - w;
            else if (xImageCoordinate < 0) xImageCoordinate = 0;

            if (yImageCoordinate >= shownImage.Height - h) 
                yImageCoordinate = shownImage.Height - h;
            else if (yImageCoordinate < 0) yImageCoordinate = 0;

            tmp.DrawImage(shownImage, new Rectangle(0, 0, w, h), new Rectangle(xImageCoordinate, yImageCoordinate, w, h), GraphicsUnit.Pixel);
            pictureBoxWindow.Refresh();
        }

        private void checkBoxLineCurve_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBoxLineCurve.Checked) { LT = LineType.CardinalCurve; checkBoxLineBroken.Checked = false; }
            else { LT = LineType.Line; checkBoxLineBroken.Checked = true; }
        }
        private void checkBoxLineBroken_CheckedChanged(object sender, EventArgs e)
        {
            checkBoxLineCurve.Checked = !checkBoxLineBroken.Checked;
        }


        /// <summary>
        /// Сохраняет в файл построенный график
        /// </summary>
        /// <param name="sender">Источник события</param>
        /// <param name="e">Параметры события</param>
        private void buttonGraphToFile_Click(object sender, EventArgs e)
        {
            if(saveFileDialog.ShowDialog(this)!=DialogResult.OK) return;

                buttonGraph_Click(this, EventArgs.Empty);
                shownImage.Save(saveFileDialog.FileName,
                    System.Drawing.Imaging.ImageFormat.Jpeg);
                MessageBox.Show(this, "Файл успешно сохранен: " + saveFileDialog.FileName, "Удалось!", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
        }

        #region MouseOperations

        bool hoverOperation = false, scaleOperation = false;
        Point firstPosition;
        int deltaX, deltaY;

        private void pictureBoxWindow_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                if (shownImage.Height > pictureBoxWindow.Height || shownImage.Width > pictureBoxWindow.Height)
                {
                    Cursor.Current = Cursors.NoMove2D;
                    firstPosition = Cursor.Position;
                    deltaX = deltaY = 0;

                    hoverOperation = true;
                }
            }
            else if(e.Button == MouseButtons.Right)
            {
                Cursor.Current = Cursors.SizeNS;
                firstPosition = Cursor.Position;
                deltaX = deltaY = 0;

                scaleOperation = true;
            }   
        }

        private void pictureBoxWindow_MouseUp(object sender, MouseEventArgs e)
        {
            if (hoverOperation == true)
            {
                hoverOperation = false;
                Cursor.Current = Cursors.Cross;
                firstPosition = Cursor.Position;
                deltaX = deltaY = 0;
            }
            else if (scaleOperation == true)
            {
                scaleOperation = false;
                Cursor.Current = Cursors.Cross;
                firstPosition = Cursor.Position;
                deltaX = deltaY = 0;
            }
        }
        
        private void pictureBoxWindow_MouseMove(object sender, MouseEventArgs e)
        {
            if (hoverOperation)
            {
                // 3 потом поменять на переменную величину
                deltaX = (Cursor.Position.X - firstPosition.X);
                deltaY = (Cursor.Position.Y - firstPosition.Y);
                
                xImageCoordinate = xImageCoordinate - deltaX;
                yImageCoordinate = yImageCoordinate - deltaY;

                if (Math.Abs(deltaX) > 1 || Math.Abs(deltaY) > 1)
                {
                    firstPosition = Cursor.Position;
                    deltaX = deltaY = 0;
                }
                
                ShowImageInPictureBox();
            }
            else if (scaleOperation && checkBoxNotWindowed.Checked)
            {
                deltaX = (Cursor.Position.X - firstPosition.X);

                int setWid = (int)((double)numericUpDownWidth.Value* (1 + (double)deltaX / 50));
                int setHei = (int)((double)numericUpDownWidth.Value* (1 + (double)deltaX / 50));

                if (setWid > numericUpDownWidth.Maximum) setWid = (int)numericUpDownWidth.Maximum;
                else if (setWid < numericUpDownWidth.Minimum) setWid = (int)numericUpDownWidth.Minimum;
                if (setHei > numericUpDownHeight.Maximum) setWid = (int)numericUpDownHeight.Maximum;
                else if (setHei < numericUpDownHeight.Minimum) setWid = (int)numericUpDownHeight.Minimum;

                numericUpDownWidth.Value = setWid;
                numericUpDownHeight.Value = setHei;

                if (Math.Abs(deltaX) > 1)
                {
                    firstPosition = Cursor.Position;
                    deltaX = deltaY = 0;
                }

                buttonGraph_Click(this, EventArgs.Empty);
            }
        }
    
        #endregion

        #region Functionality

        public void fillFunctionRectangle(Color color, int alpha, double x1, double y1, double width, double height)
        {
            if (!somethingIsDrawn) return;            
            PointF point = ctf.transformFunctionToPixel(x1, y1);
            
            fillRectangle(color, alpha, new RectangleF(point, new SizeF((float)(width*ctf.Axis1ScaleFactor), (float)(height*ctf.Axis2ScaleFactor))));
            this.Refresh();
        }

        public void fillRectangle(Color color, int alpha, RectangleF region)
        {
            if (!somethingIsDrawn) return;

            Graphics gr = Graphics.FromImage(shownImage);
            
            Color transp = Color.FromArgb(alpha, color);
            Brush br = new SolidBrush(transp);

            gr.FillRectangle(br, region);
            this.Refresh();
        }

        #endregion

    }


    // ---------------- Event handling

    /// <summary>
    /// Handler which is being called when the user clicks on the function graph.
    /// </summary>
    /// <param name="source"></param>
    /// <param name="e"></param>
    public delegate void GraphicDrawerGraphClickEventHandler(object source, GraphicDrawerGraphClickEventArgs e);

    /// <summary>
    /// The event arguments for GraphicDrawerGraphClick.
    /// </summary>
    public class GraphicDrawerGraphClickEventArgs : EventArgs
    {
        public int xPixel;
        public int yPixel;

        public Point PixelClicked
        {
            get { return new Point(xPixel, yPixel); }
        }

        public double xValue;
        public double yValue;

        public double X
        {
            get { return xValue; }
        }

        public double Y
        {
            get { return yValue; }
        }

        public GraphicDrawerGraphClickEventArgs(int xPixel, int yPixel, double X, double Y)
        {
            this.xPixel = xPixel;
            this.yPixel = yPixel;
            this.xValue = X;
            this.yValue = Y;
        }
    }
}
