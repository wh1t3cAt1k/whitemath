﻿namespace whiteMath.Graphers
{
    partial class GraphicDrawer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBoxWindow = new System.Windows.Forms.PictureBox();
            this.fontDialogForGrapher = new System.Windows.Forms.FontDialog();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.buttonRestore = new System.Windows.Forms.Button();
            this.label18 = new System.Windows.Forms.Label();
            this.textBoxToY = new System.Windows.Forms.TextBox();
            this.textBoxFromY = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.numericUpDownParts = new System.Windows.Forms.NumericUpDown();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.numericUpDownEX = new System.Windows.Forms.NumericUpDown();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.numericUpDownShift = new System.Windows.Forms.NumericUpDown();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.textBoxAW = new System.Windows.Forms.TextBox();
            this.textBoxCW = new System.Windows.Forms.TextBox();
            this.labelObjName = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.textBoxToX = new System.Windows.Forms.TextBox();
            this.textBoxFromX = new System.Windows.Forms.TextBox();
            this.numericUpDownHeight = new System.Windows.Forms.NumericUpDown();
            this.label6 = new System.Windows.Forms.Label();
            this.numericUpDownWidth = new System.Windows.Forms.NumericUpDown();
            this.checkBoxNotWindowed = new System.Windows.Forms.CheckBox();
            this.checkBoxWindowed = new System.Windows.Forms.CheckBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.buttonChooseAC = new System.Windows.Forms.Button();
            this.buttonChooseCC = new System.Windows.Forms.Button();
            this.textBoxAC = new System.Windows.Forms.TextBox();
            this.textBoxCC = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.buttonChooseFont = new System.Windows.Forms.Button();
            this.richTextBoxFontTest = new System.Windows.Forms.RichTextBox();
            this.buttonGraphToFile = new System.Windows.Forms.Button();
            this.buttonGraph = new System.Windows.Forms.Button();
            this.colorDialogForGrapher = new System.Windows.Forms.ColorDialog();
            this.panel = new System.Windows.Forms.Panel();
            this.label15 = new System.Windows.Forms.Label();
            this.checkBoxLineBroken = new System.Windows.Forms.CheckBox();
            this.checkBoxLineCurve = new System.Windows.Forms.CheckBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label16 = new System.Windows.Forms.Label();
            this.saveFileDialog = new System.Windows.Forms.SaveFileDialog();
            this.statusStrip = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabelCoord = new System.Windows.Forms.ToolStripStatusLabel();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxWindow)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownParts)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownEX)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownShift)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownHeight)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownWidth)).BeginInit();
            this.panel.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.statusStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // pictureBoxWindow
            // 
            this.pictureBoxWindow.Cursor = System.Windows.Forms.Cursors.Cross;
            this.pictureBoxWindow.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBoxWindow.Location = new System.Drawing.Point(0, 0);
            this.pictureBoxWindow.Name = "pictureBoxWindow";
            this.pictureBoxWindow.Size = new System.Drawing.Size(564, 408);
            this.pictureBoxWindow.TabIndex = 0;
            this.pictureBoxWindow.TabStop = false;
            this.pictureBoxWindow.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pictureBoxWindow_MouseMove);
            this.pictureBoxWindow.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBoxWindow_MouseDown);
            this.pictureBoxWindow.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pictureBoxWindow_MouseUp);
            // 
            // fontDialogForGrapher
            // 
            this.fontDialogForGrapher.AllowVerticalFonts = false;
            this.fontDialogForGrapher.FontMustExist = true;
            this.fontDialogForGrapher.ShowEffects = false;
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.buttonRestore);
            this.groupBox1.Controls.Add(this.label18);
            this.groupBox1.Controls.Add(this.textBoxToY);
            this.groupBox1.Controls.Add(this.textBoxFromY);
            this.groupBox1.Controls.Add(this.label17);
            this.groupBox1.Controls.Add(this.numericUpDownParts);
            this.groupBox1.Controls.Add(this.label14);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.numericUpDownEX);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.numericUpDownShift);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.textBoxAW);
            this.groupBox1.Controls.Add(this.textBoxCW);
            this.groupBox1.Controls.Add(this.labelObjName);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.textBoxToX);
            this.groupBox1.Controls.Add(this.textBoxFromX);
            this.groupBox1.Controls.Add(this.numericUpDownHeight);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.numericUpDownWidth);
            this.groupBox1.Controls.Add(this.checkBoxNotWindowed);
            this.groupBox1.Controls.Add(this.checkBoxWindowed);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.buttonChooseAC);
            this.groupBox1.Controls.Add(this.buttonChooseCC);
            this.groupBox1.Controls.Add(this.textBoxAC);
            this.groupBox1.Controls.Add(this.textBoxCC);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.buttonChooseFont);
            this.groupBox1.Controls.Add(this.richTextBoxFontTest);
            this.groupBox1.Location = new System.Drawing.Point(582, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(186, 465);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Управление рисованием";
            // 
            // buttonRestore
            // 
            this.buttonRestore.Location = new System.Drawing.Point(7, 438);
            this.buttonRestore.Name = "buttonRestore";
            this.buttonRestore.Size = new System.Drawing.Size(173, 21);
            this.buttonRestore.TabIndex = 42;
            this.buttonRestore.Text = "Восстановить начальн. знач.";
            this.buttonRestore.UseVisualStyleBackColor = true;
            this.buttonRestore.Click += new System.EventHandler(this.buttonRestore_Click);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(94, 411);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(36, 13);
            this.label18.TabIndex = 41;
            this.label18.Text = "Ymax:";
            this.label18.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // textBoxToY
            // 
            this.textBoxToY.Location = new System.Drawing.Point(133, 408);
            this.textBoxToY.Name = "textBoxToY";
            this.textBoxToY.Size = new System.Drawing.Size(47, 20);
            this.textBoxToY.TabIndex = 40;
            // 
            // textBoxFromY
            // 
            this.textBoxFromY.Location = new System.Drawing.Point(42, 408);
            this.textBoxFromY.Name = "textBoxFromY";
            this.textBoxFromY.Size = new System.Drawing.Size(47, 20);
            this.textBoxFromY.TabIndex = 39;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(8, 411);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(33, 13);
            this.label17.TabIndex = 38;
            this.label17.Text = "Ymin:";
            this.label17.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // numericUpDownParts
            // 
            this.numericUpDownParts.Location = new System.Drawing.Point(96, 357);
            this.numericUpDownParts.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numericUpDownParts.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownParts.Name = "numericUpDownParts";
            this.numericUpDownParts.Size = new System.Drawing.Size(37, 20);
            this.numericUpDownParts.TabIndex = 37;
            this.numericUpDownParts.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(9, 359);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(84, 13);
            this.label14.TabIndex = 36;
            this.label14.Text = "Делить оси на:";
            this.label14.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(73, 331);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(106, 13);
            this.label13.TabIndex = 35;
            this.label13.Text = "знака (до и после ,)";
            this.label13.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // numericUpDownEX
            // 
            this.numericUpDownEX.Location = new System.Drawing.Point(30, 329);
            this.numericUpDownEX.Maximum = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.numericUpDownEX.Name = "numericUpDownEX";
            this.numericUpDownEX.Size = new System.Drawing.Size(37, 20);
            this.numericUpDownEX.TabIndex = 34;
            this.numericUpDownEX.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(9, 311);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(143, 13);
            this.label12.TabIndex = 33;
            this.label12.Text = "Точность отметок на осях:";
            this.label12.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(162, 284);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(20, 13);
            this.label11.TabIndex = 32;
            this.label11.Text = "pix";
            this.label11.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // numericUpDownShift
            // 
            this.numericUpDownShift.Location = new System.Drawing.Point(122, 282);
            this.numericUpDownShift.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numericUpDownShift.Name = "numericUpDownShift";
            this.numericUpDownShift.Size = new System.Drawing.Size(37, 20);
            this.numericUpDownShift.TabIndex = 31;
            this.numericUpDownShift.Value = new decimal(new int[] {
            20,
            0,
            0,
            0});
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(9, 284);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(113, 13);
            this.label10.TabIndex = 30;
            this.label10.Text = "Отступ осей от края:";
            this.label10.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(160, 207);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(20, 13);
            this.label9.TabIndex = 29;
            this.label9.Text = "pix";
            this.label9.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(160, 183);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(20, 13);
            this.label1.TabIndex = 28;
            this.label1.Text = "pix";
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // textBoxAW
            // 
            this.textBoxAW.Location = new System.Drawing.Point(133, 204);
            this.textBoxAW.Name = "textBoxAW";
            this.textBoxAW.Size = new System.Drawing.Size(23, 20);
            this.textBoxAW.TabIndex = 27;
            this.textBoxAW.Text = "1";
            // 
            // textBoxCW
            // 
            this.textBoxCW.Location = new System.Drawing.Point(133, 180);
            this.textBoxCW.Name = "textBoxCW";
            this.textBoxCW.Size = new System.Drawing.Size(23, 20);
            this.textBoxCW.TabIndex = 26;
            this.textBoxCW.Text = "1";
            // 
            // labelObjName
            // 
            this.labelObjName.AutoSize = true;
            this.labelObjName.Location = new System.Drawing.Point(46, 26);
            this.labelObjName.Name = "labelObjName";
            this.labelObjName.Size = new System.Drawing.Size(96, 13);
            this.labelObjName.TabIndex = 25;
            this.labelObjName.Text = "==имя объекта==";
            this.labelObjName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(94, 391);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(36, 13);
            this.label8.TabIndex = 24;
            this.label8.Text = "Xmax:";
            this.label8.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(8, 391);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(33, 13);
            this.label7.TabIndex = 23;
            this.label7.Text = "Xmin:";
            this.label7.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // textBoxToX
            // 
            this.textBoxToX.Location = new System.Drawing.Point(132, 388);
            this.textBoxToX.Name = "textBoxToX";
            this.textBoxToX.Size = new System.Drawing.Size(48, 20);
            this.textBoxToX.TabIndex = 22;
            // 
            // textBoxFromX
            // 
            this.textBoxFromX.Location = new System.Drawing.Point(42, 388);
            this.textBoxFromX.Name = "textBoxFromX";
            this.textBoxFromX.Size = new System.Drawing.Size(47, 20);
            this.textBoxFromX.TabIndex = 21;
            // 
            // numericUpDownHeight
            // 
            this.numericUpDownHeight.Enabled = false;
            this.numericUpDownHeight.Location = new System.Drawing.Point(131, 248);
            this.numericUpDownHeight.Maximum = new decimal(new int[] {
            2048,
            0,
            0,
            0});
            this.numericUpDownHeight.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownHeight.Name = "numericUpDownHeight";
            this.numericUpDownHeight.Size = new System.Drawing.Size(45, 20);
            this.numericUpDownHeight.TabIndex = 17;
            this.numericUpDownHeight.Value = new decimal(new int[] {
            768,
            0,
            0,
            0});
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(122, 250);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(12, 13);
            this.label6.TabIndex = 16;
            this.label6.Text = "x";
            this.label6.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // numericUpDownWidth
            // 
            this.numericUpDownWidth.Enabled = false;
            this.numericUpDownWidth.Location = new System.Drawing.Point(77, 248);
            this.numericUpDownWidth.Maximum = new decimal(new int[] {
            2048,
            0,
            0,
            0});
            this.numericUpDownWidth.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownWidth.Name = "numericUpDownWidth";
            this.numericUpDownWidth.Size = new System.Drawing.Size(45, 20);
            this.numericUpDownWidth.TabIndex = 15;
            this.numericUpDownWidth.Value = new decimal(new int[] {
            1024,
            0,
            0,
            0});
            // 
            // checkBoxNotWindowed
            // 
            this.checkBoxNotWindowed.AutoSize = true;
            this.checkBoxNotWindowed.Location = new System.Drawing.Point(9, 250);
            this.checkBoxNotWindowed.Name = "checkBoxNotWindowed";
            this.checkBoxNotWindowed.Size = new System.Drawing.Size(66, 17);
            this.checkBoxNotWindowed.TabIndex = 14;
            this.checkBoxNotWindowed.Text = "Другое:";
            this.checkBoxNotWindowed.UseVisualStyleBackColor = true;
            this.checkBoxNotWindowed.CheckedChanged += new System.EventHandler(this.checkBoxNotWindowed_CheckedChanged);
            // 
            // checkBoxWindowed
            // 
            this.checkBoxWindowed.AutoSize = true;
            this.checkBoxWindowed.Checked = true;
            this.checkBoxWindowed.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxWindowed.Location = new System.Drawing.Point(9, 232);
            this.checkBoxWindowed.Name = "checkBoxWindowed";
            this.checkBoxWindowed.Size = new System.Drawing.Size(161, 17);
            this.checkBoxWindowed.TabIndex = 13;
            this.checkBoxWindowed.Text = "Разрешение для раб. окна";
            this.checkBoxWindowed.UseVisualStyleBackColor = true;
            this.checkBoxWindowed.CheckedChanged += new System.EventHandler(this.checkBoxWindowed_CheckedChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 207);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(116, 13);
            this.label5.TabIndex = 11;
            this.label5.Text = "Толщина линий осей:";
            this.label5.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 183);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(128, 13);
            this.label4.TabIndex = 9;
            this.label4.Text = "Толщина линий кривой:";
            this.label4.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // buttonChooseAC
            // 
            this.buttonChooseAC.Location = new System.Drawing.Point(149, 148);
            this.buttonChooseAC.Name = "buttonChooseAC";
            this.buttonChooseAC.Size = new System.Drawing.Size(31, 20);
            this.buttonChooseAC.TabIndex = 8;
            this.buttonChooseAC.Text = "др.";
            this.buttonChooseAC.UseVisualStyleBackColor = true;
            this.buttonChooseAC.Click += new System.EventHandler(this.buttonChooseAC_Click);
            // 
            // buttonChooseCC
            // 
            this.buttonChooseCC.Location = new System.Drawing.Point(149, 129);
            this.buttonChooseCC.Name = "buttonChooseCC";
            this.buttonChooseCC.Size = new System.Drawing.Size(31, 20);
            this.buttonChooseCC.TabIndex = 7;
            this.buttonChooseCC.Text = "др.";
            this.buttonChooseCC.UseVisualStyleBackColor = true;
            this.buttonChooseCC.Click += new System.EventHandler(this.buttonChooseCC_Click);
            // 
            // textBoxAC
            // 
            this.textBoxAC.Location = new System.Drawing.Point(119, 148);
            this.textBoxAC.Name = "textBoxAC";
            this.textBoxAC.ReadOnly = true;
            this.textBoxAC.Size = new System.Drawing.Size(27, 20);
            this.textBoxAC.TabIndex = 6;
            // 
            // textBoxCC
            // 
            this.textBoxCC.Location = new System.Drawing.Point(119, 129);
            this.textBoxCC.Name = "textBoxCC";
            this.textBoxCC.ReadOnly = true;
            this.textBoxCC.Size = new System.Drawing.Size(27, 20);
            this.textBoxCC.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 152);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(95, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Цвет линий осей:";
            this.label3.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 132);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(107, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Цвет линий кривой:";
            this.label2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // buttonChooseFont
            // 
            this.buttonChooseFont.Location = new System.Drawing.Point(7, 96);
            this.buttonChooseFont.Name = "buttonChooseFont";
            this.buttonChooseFont.Size = new System.Drawing.Size(173, 23);
            this.buttonChooseFont.TabIndex = 2;
            this.buttonChooseFont.Text = "Выбрать шрифт...";
            this.buttonChooseFont.UseVisualStyleBackColor = true;
            this.buttonChooseFont.Click += new System.EventHandler(this.buttonChooseFont_Click);
            // 
            // richTextBoxFontTest
            // 
            this.richTextBoxFontTest.Location = new System.Drawing.Point(6, 52);
            this.richTextBoxFontTest.Name = "richTextBoxFontTest";
            this.richTextBoxFontTest.ReadOnly = true;
            this.richTextBoxFontTest.Size = new System.Drawing.Size(174, 38);
            this.richTextBoxFontTest.TabIndex = 1;
            this.richTextBoxFontTest.Text = "1 2.3 Образец шрифта";
            // 
            // buttonGraphToFile
            // 
            this.buttonGraphToFile.Location = new System.Drawing.Point(341, 19);
            this.buttonGraphToFile.Name = "buttonGraphToFile";
            this.buttonGraphToFile.Size = new System.Drawing.Size(223, 35);
            this.buttonGraphToFile.TabIndex = 19;
            this.buttonGraphToFile.Text = "Сохранить в файл...";
            this.buttonGraphToFile.UseVisualStyleBackColor = true;
            this.buttonGraphToFile.Click += new System.EventHandler(this.buttonGraphToFile_Click);
            // 
            // buttonGraph
            // 
            this.buttonGraph.Location = new System.Drawing.Point(171, 19);
            this.buttonGraph.Name = "buttonGraph";
            this.buttonGraph.Size = new System.Drawing.Size(164, 35);
            this.buttonGraph.TabIndex = 18;
            this.buttonGraph.Text = "Строить график";
            this.buttonGraph.UseVisualStyleBackColor = true;
            this.buttonGraph.Click += new System.EventHandler(this.buttonGraph_Click);
            // 
            // panel
            // 
            this.panel.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel.Controls.Add(this.pictureBoxWindow);
            this.panel.Location = new System.Drawing.Point(12, 12);
            this.panel.Name = "panel";
            this.panel.Size = new System.Drawing.Size(564, 408);
            this.panel.TabIndex = 2;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(721, 371);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(32, 13);
            this.label15.TabIndex = 38;
            this.label15.Text = "част.";
            this.label15.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // checkBoxLineBroken
            // 
            this.checkBoxLineBroken.AutoSize = true;
            this.checkBoxLineBroken.Checked = true;
            this.checkBoxLineBroken.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxLineBroken.Location = new System.Drawing.Point(84, 33);
            this.checkBoxLineBroken.Name = "checkBoxLineBroken";
            this.checkBoxLineBroken.Size = new System.Drawing.Size(72, 17);
            this.checkBoxLineBroken.TabIndex = 38;
            this.checkBoxLineBroken.Text = "Ломаная";
            this.checkBoxLineBroken.UseVisualStyleBackColor = true;
            this.checkBoxLineBroken.CheckedChanged += new System.EventHandler(this.checkBoxLineBroken_CheckedChanged);
            // 
            // checkBoxLineCurve
            // 
            this.checkBoxLineCurve.AutoSize = true;
            this.checkBoxLineCurve.Location = new System.Drawing.Point(15, 33);
            this.checkBoxLineCurve.Name = "checkBoxLineCurve";
            this.checkBoxLineCurve.Size = new System.Drawing.Size(63, 17);
            this.checkBoxLineCurve.TabIndex = 39;
            this.checkBoxLineCurve.Text = "Кривая";
            this.checkBoxLineCurve.UseVisualStyleBackColor = true;
            this.checkBoxLineCurve.CheckedChanged += new System.EventHandler(this.checkBoxLineCurve_CheckedChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.groupBox2.Controls.Add(this.label16);
            this.groupBox2.Controls.Add(this.checkBoxLineCurve);
            this.groupBox2.Controls.Add(this.checkBoxLineBroken);
            this.groupBox2.Controls.Add(this.buttonGraphToFile);
            this.groupBox2.Controls.Add(this.buttonGraph);
            this.groupBox2.Location = new System.Drawing.Point(7, 416);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(570, 58);
            this.groupBox2.TabIndex = 40;
            this.groupBox2.TabStop = false;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(32, 13);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(97, 13);
            this.label16.TabIndex = 40;
            this.label16.Text = "Рисовать линией:";
            // 
            // saveFileDialog
            // 
            this.saveFileDialog.DefaultExt = "jpg";
            this.saveFileDialog.Filter = "JPEG files|*.jpg";
            // 
            // statusStrip
            // 
            this.statusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel,
            this.toolStripStatusLabelCoord});
            this.statusStrip.Location = new System.Drawing.Point(0, 473);
            this.statusStrip.Name = "statusStrip";
            this.statusStrip.Size = new System.Drawing.Size(780, 22);
            this.statusStrip.TabIndex = 41;
            this.statusStrip.Text = "statusStrip1";
            // 
            // toolStripStatusLabel
            // 
            this.toolStripStatusLabel.Name = "toolStripStatusLabel";
            this.toolStripStatusLabel.Size = new System.Drawing.Size(81, 17);
            this.toolStripStatusLabel.Text = "Координаты: ";
            // 
            // toolStripStatusLabelCoord
            // 
            this.toolStripStatusLabelCoord.Name = "toolStripStatusLabelCoord";
            this.toolStripStatusLabelCoord.Size = new System.Drawing.Size(67, 17);
            this.toolStripStatusLabelCoord.Text = "X = 0, Y = 0";
            // 
            // GraphicDrawer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(780, 495);
            this.Controls.Add(this.statusStrip);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.panel);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "GraphicDrawer";
            this.Text = "GraphicDrawer";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxWindow)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownParts)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownEX)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownShift)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownHeight)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownWidth)).EndInit();
            this.panel.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.statusStrip.ResumeLayout(false);
            this.statusStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBoxWindow;
        private System.Windows.Forms.FontDialog fontDialogForGrapher;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ColorDialog colorDialogForGrapher;
        private System.Windows.Forms.RichTextBox richTextBoxFontTest;
        private System.Windows.Forms.Button buttonChooseFont;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBoxAC;
        private System.Windows.Forms.TextBox textBoxCC;
        private System.Windows.Forms.Button buttonChooseAC;
        private System.Windows.Forms.Button buttonChooseCC;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.CheckBox checkBoxWindowed;
        private System.Windows.Forms.NumericUpDown numericUpDownHeight;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.NumericUpDown numericUpDownWidth;
        private System.Windows.Forms.CheckBox checkBoxNotWindowed;
        private System.Windows.Forms.Button buttonGraphToFile;
        private System.Windows.Forms.Button buttonGraph;
        private System.Windows.Forms.TextBox textBoxToX;
        private System.Windows.Forms.TextBox textBoxFromX;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label labelObjName;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBoxAW;
        private System.Windows.Forms.TextBox textBoxCW;
        private System.Windows.Forms.Panel panel;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.NumericUpDown numericUpDownShift;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.NumericUpDown numericUpDownEX;
        private System.Windows.Forms.NumericUpDown numericUpDownParts;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.CheckBox checkBoxLineBroken;
        private System.Windows.Forms.CheckBox checkBoxLineCurve;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.SaveFileDialog saveFileDialog;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox textBoxToY;
        private System.Windows.Forms.TextBox textBoxFromY;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Button buttonRestore;
        private System.Windows.Forms.StatusStrip statusStrip;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabelCoord;
    }
}