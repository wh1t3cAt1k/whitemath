﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;

namespace whiteMath.Graphers
{
    [Serializable]
    public class CoordinateTransformer
    {
        private double xMin, xMax, yMin, yMax;
        private int imgWidth, imgHeight;
        private int imgBorderIndent;
        private double kx, ky;

        #region PointCalculators

        public PointF CoordinateSystemZero
        {
            get
            {
                calculateKX();
                calculateKY();

                float xType;

                if (xMin >= 0)
                    xType = imgBorderIndent;
                else if (xMax <= 0)
                    xType = imgWidth - imgBorderIndent;
                else
                    xType = (float)(imgWidth - imgBorderIndent - xMax * kx);

                float yType;

                if (yMin >= 0)
                    yType = imgHeight - imgBorderIndent;
                else if (yMax <= 0)
                    yType = imgBorderIndent;
                else
                    yType = (float)(imgBorderIndent + yMax * ky);

                return new PointF(xType, yType);
            }
        }

        public PointF CoordinateSystemLeft
        {
            get
            {
                calculateKY();

                float xType = imgBorderIndent;

                float yType;

                if (yMin >= 0)
                    yType = imgHeight - imgBorderIndent;
                else if (yMax <= 0)
                    yType = imgBorderIndent;
                else
                    yType = (float)(imgBorderIndent + yMax * ky);

                return new PointF(xType, yType);
            }
        }

        public PointF CoordinateSystemRight
        {
            get
            {
                calculateKY();

                float xType = imgWidth - imgBorderIndent;

                float yType;

                if (yMin >= 0)
                    yType = imgHeight - imgBorderIndent;
                else if (yMax <= 0)
                    yType = imgBorderIndent;
                else
                    yType = (float)(imgBorderIndent + yMax * ky);

                return new PointF(xType, yType);
            }
        }

        public PointF CoordinateSystemUp
        {
            get
            {
                calculateKX();

                float xType;

                if (xMin >= 0)
                    xType = imgBorderIndent;
                else if (xMax <= 0)
                    xType = imgWidth - imgBorderIndent;
                else
                    xType = (float)(imgWidth - imgBorderIndent - xMax * kx);

                float yType = imgBorderIndent;

                return new PointF(xType, yType);
            }
        }

        public PointF CoordinateSystemDown
        {
            get
            {
                calculateKX();

                float xType;

                if (xMin >= 0)
                    xType = imgBorderIndent;
                else if (xMax <= 0)
                    xType = imgWidth - imgBorderIndent;
                else
                    xType = (float)(imgWidth - imgBorderIndent - xMax * kx);

                float yType = imgHeight - imgBorderIndent;

                return new PointF(xType, yType);
            }
        }

        #endregion

        // ------------------ public properties

        public double MinAxis1 { get { return xMin; } }
        public double MaxAxis1 { get { return xMax; } }
        public double MinAxis2 { get { return yMin; } }
        public double MaxAxis2 { get { return yMax; } }

        public double Axis1ScaleFactor { get { calculateKX(); return kx; } }
        public double Axis2ScaleFactor { get { calculateKY(); return ky; } }

        /// <summary>
        /// Returns the image size that current CoordinateTransformer is set to.
        /// </summary>
        /// <returns></returns>
        public Size getImageSize()
        {
            return new Size(imgWidth, imgHeight);
        }

        /// <summary>
        /// Sets the image size for current CoordinateTransformer.
        /// </summary>
        /// <param name="imgSize"></param>
        public void setImageSize(Size imgSize)
        {
            imgWidth = imgSize.Width; 
            imgHeight = imgSize.Height;
        }

        /// <summary>
        /// Returns the value of the image border indent for
        /// </summary>
        public int getImageBorderIndent()
        {
            return imgBorderIndent;
        }
    
        /// <summary>
        /// Sets the value of image border indent for the current CoordinateTransformer
        /// </summary>
        /// <param name="imgBorderIndent"></param>
        public void setImageBorderIndent(int imgBorderIndent)
        {
            this.imgBorderIndent = imgBorderIndent;
        }

        // ------------------------------------

        private void calculateKX()
        {
            if (xMax - xMin == 0)
                throw new ArgumentException("The length of Axis1 graphing range is zero. The CoordinateTransformer possibly hasn't been initialized.");

            kx = (this.imgWidth - imgBorderIndent * 2) / (xMax - xMin);
            return;
        }

        private void calculateKY()
        {
            if (yMax - yMin == 0)
                throw new ArgumentException("The length of Axis1 graphing range is zero. The CoordinateTransformer possibly hasn't been initialized.");

            ky = (this.imgHeight - imgBorderIndent * 2) / (yMax - yMin);
            return;
        }

        // ------------------------------------

        public void setAxis1GraphingRange(double xMin, double xMax)
        {
            this.xMin = xMin;
            this.xMax = xMax;
        }

        public void setAxis2GraphingRange(double yMin, double yMax)
        {
            this.yMin = yMin;
            this.yMax = yMax;
        }

        public void setGraphingRange(double xMin, double xMax, double yMin, double yMax)
        {
            setAxis1GraphingRange(xMin, xMax);
            setAxis2GraphingRange(yMin, yMax);
        }

        // ------------------------------------

        public CoordinateTransformer() 
            {}

        public CoordinateTransformer(double xMin, double xMax, double yMin, double yMax, Size imgSize, int imgBorderIndent)
            : this(xMin, xMax, yMin, yMax, imgSize.Width, imgSize.Height, imgBorderIndent) { }

        public CoordinateTransformer(double xMin, double xMax, double yMin, double yMax, int imgWidth, int imgHeight, int imgBorderIndent)
        {
            this.xMin = xMin;
            this.xMax = xMax;
            this.yMin = yMin;
            this.yMax = yMax;
            this.imgWidth = imgWidth;
            this.imgHeight = imgHeight;
            this.imgBorderIndent = imgBorderIndent;
        }

        // ------------Transforming methods--------------------

        public void transformPixelToFunction(PointF pixel, out double x, out double y)
        {
            PointF zero = CoordinateSystemZero;     // calculates kx and ky inside

            x = transformImageXtoFunctionX(pixel.X);
            y = transformImageYToFunctionY(pixel.Y);
            
            return;
        }

        public double transformImageXtoFunctionX(float pixelX)
        {
            PointF zero = CoordinateSystemZero;
            return (pixelX + (xMax * kx * (xMax <= 0 ? 1 : 0)) + (xMin * kx * (xMin >= 0 ? 1 : 0)) - zero.X) / kx;
        }

        public double transformImageYToFunctionY(float pixelY)
        {
            PointF zero = CoordinateSystemZero;
            return -(pixelY - (yMax * ky * (yMax <= 0 ? 1 : 0)) - (yMin * ky * (yMin >= 0 ? 1 : 0)) - zero.Y) / ky;
        }

        public PointF transformFunctionToPixel(double x, double y)
        {
            PointF zero = CoordinateSystemZero;     // calculates kx and ky inside

            return new PointF((float)(zero.X + x * kx - (xMax * kx * (xMax <= 0 ? 1 : 0)) -
                                   xMin * kx * (xMin >= 0 ? 1 : 0)), //
                               (float)(zero.Y - y * ky + yMax * ky * (yMax <= 0 ? 1 : 0) +
                                    yMin * ky * (yMin >= 0 ? 1 : 0)));
        }

        // ------------OBJECT METHODS OVERRIDING---------------

        public override bool Equals(object obj)
        {
            if (this.GetType().IsInstanceOfType(obj))
            {
                CoordinateTransformer ct = obj as CoordinateTransformer;
                return ct.imgHeight == this.imgHeight &&
                       ct.imgWidth == this.imgWidth &&
                       ct.xMin == this.xMin &&
                       ct.xMax == this.xMax &&
                       ct.yMin == this.yMin &&
                       ct.yMax == this.yMax;
            }
            else return false;
        }

        public override string ToString()
        {
            return String.Format("Coordinate transformer: " +
                "xRange = {0}-{1} yRange = {2}-{3} " +
                "imgWidth = {4} imgHeight = {5}", xMin, xMax, yMin, yMax, imgWidth, imgHeight);
        }

        public override int GetHashCode()
        {
            return (int)xMax % imgWidth + (int)xMin % imgWidth +
                (int)yMin % imgHeight + (int)yMax % imgHeight;
        }
    }
}
