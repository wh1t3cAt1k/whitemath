﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace whiteMath
{
    public static partial class WhiteMath<T, C> where C : ICalc<T>, new()
    {
        private static C calculator = new C();

        /// HERON SQUARE ROOT
        /// 
        /// <summary>
        /// Performs a square root calculation using simple Heron algorithm.
        /// Works only for "positive" (number >= calculator.zero()) numbers.
        /// Calculator should have reasonable fromInt() method implemented, because of the formula:
        /// 
        /// x_{n+1} = 1/2 * (x_{n} + a/x_{n})
        /// 
        /// Iteration would stop when the absolute difference between the numbers
        /// is less than epsilon parameter or when the iteration step results in no change.
        /// 
        /// Restrictions:
        /// 
        /// 1. The calculator should have reasonable fromInt() method implemented and return a correct
        /// equivalent for "2".
        /// 2. Suitable for floating-point numbers.
        /// 
        /// Speed:
        /// 
        /// Due to genericity, the x_{0} is evaluated equal to the passed number.
        /// About log(N) iterations is needed.
        /// 
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <typeparam name="C"></typeparam>
        /// <param name="number"></param>
        /// <returns></returns>
        public static T SquareRootHeron(T number, T epsilon)
        {
            if (calculator.mor(calculator.zero, number))
                throw new ArgumentException("The number passed: "+number.ToString()+" is a forbidden negative value.");

            Numeric<T,C> twoEquivalent = calculator.fromInt(2);

            Numeric<T,C> xOld;
            Numeric<T,C> xNew;

            xOld = number;

            while(true)
            {
                xNew = (xOld + number / xOld) / twoEquivalent;
                if (xNew == xOld || calculator.mor(epsilon, Abs(xNew - xOld))) break;
                xOld = xNew;
            }

            return xNew;
        }

        /// POWER INTEGER
        /// 
        /// <summary>
        /// Performs the quick mathematical power operation.
        /// Works only for integer exponent values.
        /// </summary>
        /// <param name="number"></param>
        /// <param name="power"></param>
        /// <returns></returns>
        public static T PowerInteger(T number, long power)
        {
            if (power == 0) return calculator.fromInt(1);
            if (power < 0) return calculator.div(calculator.fromInt(1),PowerInteger(number, -power));

            Numeric<T,C> res = calculator.fromInt(1);              // результат возведения в степень
            Numeric<T,C> copy = calculator.getCopy(number);        // изменяемая копия (переданное число может быть ссылочным типом)

            while (power > 0)
            {
                // Если остаток от деления на 2 равен 1
                if ((power & 1) == 1)
                    res *= copy;
                copy *= copy;
                power >>= 1;
            }

            return res;
        }

        /// NATURAL LOGARITHM
        ///
        /// <summary>
        /// Returns the natural logarithm for the number specified
        /// using Taylor's series.
        /// </summary>
        /// <param name="number">Number whose logarithm should be found.</param>
        /// <param name="TaylorMemberCount">Maximum amount of Taylor series members that should be estimated.</param>
        public static T LogarithmNatural(T number, int TaylorMemberCount)
        {
            return default(T);
        }

    }
}
