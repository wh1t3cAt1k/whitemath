﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace whiteMath
{
    public static partial class WhiteMath<T, C> where C : ICalc<T>, new()
    {
        /// <summary>
        /// Finds the greatest common divisor of two integer-like numbers
        /// using the simple Euclid algorithm.
        /// 
        /// The calculator for the numbers should provide reasonable implementation
        /// of the remainder operation (%).
        /// 
        /// Is not supposed to work with floating-point numbers.
        /// </summary>
        /// <param name="one"></param>
        /// <param name="two"></param>
        /// <returns></returns>
        public static T GreatestCommonDivisor(T one, T two)
        {
            // T может быть ссылочным типом, поэтому необходимо
            // предостеречь объекты от изменения

            T oneTmp = calculator.getCopy(one);
            T twoTmp = calculator.getCopy(two);

            while (!calculator.eqv(oneTmp,calculator.zero) && !calculator.eqv(twoTmp,calculator.zero))
            {
                if (calculator.mor(oneTmp, twoTmp))
                    oneTmp = calculator.rem(oneTmp, twoTmp);
                else
                    twoTmp = calculator.rem(twoTmp, oneTmp);
            }

            return calculator.sum(oneTmp, twoTmp);
        }

        /// <summary>
        /// Finds the lowest common multiple of two integer-like numbers from the equation:
        /// A * B = gcd(A,B) * lcm(A,B)
        /// 
        /// The greatest common divisor can be explicitly specified by the user.
        /// Otherwise, it will take some time to be implicitly calculated.
        /// </summary>
        /// <param name="one"></param>
        /// <param name="two"></param>
        /// <param name="gcd">The greatest common divisor for the numbers. Optional, if nothing is specified, it will be calculated.</param>
        /// <returns></returns>
        public static T LowestCommonMultiple(T one, T two, T gcd)
        {
            return calculator.div(calculator.mul(one, two), gcd);
        }
    }
}
