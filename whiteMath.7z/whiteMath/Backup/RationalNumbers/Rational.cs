﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace whiteMath
{
    /// <summary>
    /// The struct representing the rational number as a pair of integer-like numbers.
    /// For example:
    /// <example>Rational&lt;LongInt, CalcLongInt&mt;</example>
    /// <example>Rational&lt;int, CalcInt&mt;</example>
    /// </summary>
    /// <typeparam name="T">The integer-like type of numerator and denominator.</typeparam>
    public partial class Rational<T, C> : ICloneable where C : ICalc<T>, new()
    {
        private static C calc = new C();

        private T num;          // числитель
        private T denom;        // знаменатель

        // todo: сделать default-value denominator = calc.fromInt(1);

        /// <summary>
        /// The standard constructor for generic Rational numbers.
        /// User should explicitly specify both the numerator and the denumerator.
        /// </summary>
        /// <param name="numerator"></param>
        /// <param name="denominator"></param>
        public Rational(T numerator, T denominator)
        {
            num = calc.getCopy(numerator);
            denom = calc.getCopy(denominator);

            normalize();
        }

        /// <summary>
        /// Parameterless constructor for inner purposes.
        /// </summary>
        public Rational() { }

        /// <summary>
        /// Нормализует число, делит числитель и знаменатель на НОД,
        /// делает числитель положительным.
        /// </summary>
        private void normalize()
        {
            T gcd = WhiteMath<T, C>.GreatestCommonDivisor(WhiteMath<T, C>.Abs(num), WhiteMath<T, C>.Abs(denom));

            num = calc.div(num, gcd);
            denom = calc.div(denom, gcd);

            // Если знаменатель меньше нуля
            if (calc.mor(calc.zero, denom))
            {
                num = calc.negate(num);
                denom = calc.negate(denom);
            }
        }

        /// <summary>
        /// Проверяет число на то, не бесконечность ли оно случаем.
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        private static bool checkInf(ref Rational<T, C> obj)
        {
            if (calc.eqv(obj.denom, calc.zero))
            {
                if (calc.eqv(obj.num, calc.zero))
                    obj = NaN;
                else if (calc.mor(calc.zero, obj.num))
                    obj = NegativeInfinity;
                else
                    obj = PositiveInfinity;

                return false;
            }

            return true;
        }

        ///-----------------------------------
        ///----ARITHMETIC OPERATORS-----------
        ///-----------------------------------

        public static Rational<T, C> operator +(Rational<T, C> one, Rational<T, C> two)
        {

            Rational<T, C> tmp = new Rational<T, C>();

            tmp.denom = WhiteMath<T, C>.LowestCommonMultiple(one.denom, two.denom, WhiteMath<T, C>.GreatestCommonDivisor(one.denom, two.denom));
            tmp.num = calc.sum(calc.mul(one.num, calc.div(tmp.denom, one.denom)), calc.mul(two.num, calc.div(tmp.denom, two.denom)));

            if (checkInf(ref tmp)) tmp.normalize();
            return tmp;
        }

        public static Rational<T, C> operator -(Rational<T, C> one, Rational<T, C> two)
        {
            Rational<T, C> tmp = new Rational<T, C>();

            tmp.denom = WhiteMath<T, C>.LowestCommonMultiple(one.denom, two.denom, WhiteMath<T, C>.GreatestCommonDivisor(one.denom, two.denom));
            tmp.num = calc.dif(calc.mul(one.num, calc.div(tmp.denom, one.denom)), calc.mul(two.num, calc.div(tmp.denom, two.denom)));

            if (checkInf(ref tmp)) tmp.normalize();
            return tmp;
        }

        public static Rational<T, C> operator *(Rational<T, C> one, Rational<T, C> two)
        {
            return new Rational<T, C>(calc.mul(one.num, two.num), calc.mul(one.denom, two.denom));
        }

        public static Rational<T, C> operator /(Rational<T, C> one, Rational<T, C> two)
        {
            if (calc.eqv(two.num, calc.zero)) { Rational<T, C> tmp = new Rational<T, C>(one.num, calc.zero); checkInf(ref tmp); return tmp; }
            return new Rational<T, C>(calc.mul(one.num, two.denom), calc.mul(one.denom, two.num));
        }

        ///-----------------------------------
        ///----LOGICAL OPERATORS--------------
        ///-----------------------------------

        public static bool operator ==(Rational<T, C> one, Rational<T, C> two)
        {
            return one.Equals(two);
        }

        public static bool operator !=(Rational<T, C> one, Rational<T, C> two)
        {
            return !(one == two);
        }

        public static bool operator >(Rational<T, C> one, Rational<T, C> two)
        {
            if (one is NotANumber || two is NotANumber) return false;
            else if (one is Positive_Infinity || two is Negative_Infinity) return true;
            else if (two is Positive_Infinity || one is Negative_Infinity) return false;

            T denomLcm = WhiteMath<T, C>.LowestCommonMultiple(one.denom, two.denom, WhiteMath<T, C>.GreatestCommonDivisor(one.denom, two.denom));
            return calc.mor(calc.mul(one.num, calc.div(denomLcm, one.denom)), calc.mul(two.num, calc.div(denomLcm, two.denom)));
        }

        public static bool operator <(Rational<T, C> one, Rational<T, C> two)
        {
            if (one is NotANumber || two is NotANumber) return false;
            else if (one is Positive_Infinity || two is Negative_Infinity) return false;
            else if (two is Positive_Infinity || one is Negative_Infinity) return true;

            return two > one;
        }

        public static bool operator >=(Rational<T, C> one, Rational<T, C> two)
        {
            return !(two > one);
        }

        public static bool operator <=(Rational<T, C> one, Rational<T, C> two)
        {
            return !(one > two);
        }

        ///-----------------------------------
        ///----IMPLICIT CONVERSION OPERATORS--
        ///-----------------------------------

        // Со знаменателем, равным единице.
        public static implicit operator Rational<T, C>(T num)
        {
            return new Rational<T, C>(num, calc.fromInt(1));
        }

        ///-----------------------------------
        ///-----INHERITED OVERRIDING----------
        ///-----------------------------------

        public object Clone()
        {
            return new Rational<T, C>(this.num, this.denom);
        }

        public override int GetHashCode()
        {
            return num.GetHashCode() + denom.GetHashCode();
        }

        public override bool Equals(object obj)
        {
            if (!(obj is Rational<T, C>)) return false;
            else if (one is Infinities || two is Infinities)
            {
                if (one is Positive_Infinity && two is Positive_Infinity ||
                    one is Negative_Infinity && two is Negative_Infinity)
                    return true;
                
                return false;
            }
            else
                return (obj as Rational<T, C>).num.Equals(this.num) && (obj as Rational<T, C>).denom.Equals(this.denom);
        }

        public override string ToString()
        {
            return num.ToString() + "/" + denom.ToString();
        }
    }
}
