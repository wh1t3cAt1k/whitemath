﻿using System;
using System.Runtime.InteropServices;

namespace whiteMath.Time
{
    public class NanoStopwatch
    {
            private bool processFinished = true;
            public bool Finished { get { return processFinished; } }

            private bool paused = false;
            public bool Paused { get { return paused; } }

            private long frequency = 0;

            private long firstCount = 0;
            private long sum = 0;
            private long secondCount = 0;

            public long getIntervalInNanos()
            {
                checkStopped();
                return (sum + secondCount - firstCount) * 1000000000 / frequency;
            }

            public long getIntervalInTicks()
            {
                checkStopped();
                return (sum + secondCount - firstCount);
            }

            public long getMeasuredTPS()
            {
                checkStopped();
                return frequency;
            }

            // checks if the timer is stopped - else throws an exception.
            private void checkStopped()
            {
                if (!processFinished) throw new ApplicationException("Timer is not stopped.");
                return;
            }

            [DllImport("kernel32.dll")]
            private extern static int QueryPerformanceCounter(ref long x);

            // returns current value of performance counter in ticks
            // value is written to X

            [DllImport("kernel32.dll")]
            private extern static int QueryPerformanceFrequency(ref long x);

            // returns current frequency, in counts per second
            // value is written to X

            public void start()
            {
                if (!processFinished && !paused)
                    throw new ApplicationException("Cannot start the timer - it's already running.");
                paused = processFinished = false;

                // do the calculations, if not supported, throw an exception.
                if (QueryPerformanceCounter(ref firstCount) <= 0 || QueryPerformanceFrequency(ref frequency) <= 0)
                    throw new NotSupportedException("The hardware does not support high-performance timers.");
            }

            public void pause()
            {
                if (processFinished)
                    throw new ApplicationException("Cannot pause the timer - it's not started.");

                paused = true;

                long temp = 0;
                QueryPerformanceCounter(ref temp);
                QueryPerformanceFrequency(ref frequency);
                sum += temp - firstCount;
            }

            public void stop()
            {
                if (processFinished)
                    throw new ApplicationException("Cannot stop the timer - it's not started.");

                QueryPerformanceCounter(ref secondCount);
                QueryPerformanceFrequency(ref frequency);
                processFinished = true;
            }

            public void reset()
            {
                firstCount = sum = secondCount = frequency = 0;
                processFinished = true;
            }
        }
}
