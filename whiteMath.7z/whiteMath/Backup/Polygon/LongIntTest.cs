﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using whiteMath.ArithmeticLong;
using whiteMath;

namespace Polygon
{
    static class LongIntTest
    {
        public static decimal performTest(int tests, int minNum, int maxNum)
        {
            Random gen = new Random();
            decimal successes = 0;

            for (int i = 0; i < tests; i++)
            {
                int fir = gen.Next(minNum, maxNum);
                int sec = gen.Next(minNum, maxNum);

                Console.Write("{0} {1} ", fir, sec);

                LongInt first = fir;
                LongInt second = sec;

                Console.WriteLine("{0} {1}", first, second);

                    if (fir * sec == first * second)
                        successes++;
                    if (fir + sec == first + second)
                        successes++;
                    if (fir - sec == first - second)
                        successes++;

                    if (sec == 0) successes++;
                    else if (fir / sec == first / sec)
                        successes++;
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("{0} != {1}", fir / sec, first / sec);
                        Console.ForegroundColor = ConsoleColor.White;
                    }

                    if (sec == 0) successes++;
                    else if (fir / sec == first / second)
                        successes++;
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine("{0} != {1}", fir / sec, first / second);
                        Console.ForegroundColor = ConsoleColor.White;
                    }

                    if (fir * sec == first * sec)
                        successes++;
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine(fir * sec == first * sec);
                        Console.WriteLine("WAR {0} != {1}", fir * sec, first * sec);
                        Console.ForegroundColor = ConsoleColor.White;
                    
                    }

                // TODO:: division
            }

            return successes / (tests*6);
        }
    }
}
