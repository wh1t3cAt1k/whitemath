﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Windows.Forms;

using whiteMath;
using whiteMath.Time;
using whiteMath.Matrices;
using whiteMath.Graphers;
using whiteMath.Functions;
using whiteMath.Calculators;
using whiteMath.ArithmeticLong;

using Math = whiteMath.WhiteMath<whiteMath.ArithmeticLong.LongInt, whiteMath.Calculators.CalcLongInt>;
using Rational = whiteMath.Rational<int, whiteMath.Calculators.CalcInt>;

namespace Polygon
{
    class Program
    {
        static void Main(string[] args)
        {
            Rational one = new Rational<int, CalcInt>(1, 11);
            Rational two = new Rational<int, CalcInt>(2, 10);

            Console.WriteLine(one - two);

            /*
            int N = 5000;

            Complex[] array = new Complex[N];
            Complex[] array2 = new Complex[N];

            Random gen = new Random();

            for (int i = 0; i < N; i++)
            {
                array[i] = new Complex(gen.NextDouble(), gen.NextDouble());
                array2[i] = new Complex(gen.NextDouble(), gen.NextDouble());
            }

            NanoStopwatch tic = new NanoStopwatch();

            tic.start();
            for (int i = 0; i < N; i++)
                ComplexHelper.MultiplyKaratsuba(array[i], array2[i]);
            tic.stop();

            Console.WriteLine(tic.getIntervalInNanos());

            tic.reset();
            tic.start();
            for (int i = 0; i < N; i++)
                ComplexHelper.MultiplySimple(array[i], array2[i]);
            tic.stop();

            Console.WriteLine(tic.getIntervalInNanos());
            */
            /*
            decimal one = LongIntTest.performTest(1000, -10000, 10000);
            Console.WriteLine(one);
            */

            /*
            Image bmp = GrapherHelper.GetBlankImage(800, 600, Color.LightYellow);
            FunctionGrapher fg = new FunctionGrapher(new AnalyticFunction("f(x) = 1/(x-0.1)"));
            fg.DotCount = 10000;

            CoordinateTransformer ctf = new CoordinateTransformer(-5, 5, -5, 5, bmp.Size, 0);

            double one, two;
            ctf.transformPixelToFunction(ctf.transformFunctionToPixel(4, 2), out one, out two);

            Console.WriteLine("{0} {1}", one, two);

            fg.Graph(bmp, new GraphingArgs(0, Pens.Black, Pens.Black, Pens.Black, SystemFonts.DefaultFont, LineType.CardinalCurve, true, true, true), -5, 5, -5, 5);

            new GraphicDrawer(fg, -5, 5, -5, 5).ShowDialog();
            */
            /*
            const int N = 512;

            Matrix_SDA mat = new double[,] { { 1, 2, 3 }, { 4, 5, 6 }, { 7, 8, 9 } };
            IWinder winder = Winders.getChaoticWinder(mat);

            double[] sda = mat.unwindToArray(winder);

            for (int i = 0; i < sda.Length; i++)
                Console.Write(sda[i] + " ");
            */
            /*
            Matrix_SDA one = new Matrix_SDA(N, N);
            Matrix_SDA two = new Matrix_SDA(N, N);

            Matrix_SDA three = new Matrix_SDA(N,N);


            Random gen = new Random();

            Console.WriteLine("Rows: " + one.RowCount);
            Console.WriteLine("Columns: " + one.ColumnCount);
            Console.WriteLine("Elements: " + one.ElementCount);

            NanoStopwatch tic = new NanoStopwatch();

            tic.start();
            MatrixHelper.multiplySimple(one, two, three);
            tic.stop();

            Console.WriteLine(tic.getIntervalInNanos()/(double)1000000);

            /*
            Console.WriteLine("------------------");
            for (int i = 0; i < three.RowCount; i++)
            {
                for (int j = 0; j < three.ColumnCount; j++)
                    Console.Write(three[i, j] + " ");
                Console.WriteLine();
            }*/
/*
            tic.start();
            // MatrixHelper.multiplyStrassen(one, two, three);
            tic.stop();

            Console.WriteLine(tic.getIntervalInNanos() / (double)1000000);
            */
            /*
            Console.WriteLine("------------------");
            for (int i = 0; i < three.RowCount; i++)
            {
                for (int j = 0; j < three.ColumnCount; j++)
                    Console.Write(three[i, j] + " ");
                Console.WriteLine();
            }*/
        }
    }
}
