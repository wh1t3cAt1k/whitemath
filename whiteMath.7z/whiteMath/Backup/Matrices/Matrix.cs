﻿using System;
using System.Numeric;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace whiteMath.Matrices
{
    /// <summary>
    /// The generic class for matrices.
    /// </summary>
    /// <typeparam name="T">The type of matrix elements</typeparam>
    public abstract class Matrix<T> : ICloneable, IMatrix
    {
        // public abstract T this[int row, int column] { get; set; }
        // public T this[IndexPair indexPair] { get { return this[indexPair.row, indexPair.column]; } set { this[indexPair.row, indexPair.column] = value; } }

        /// <summary>
        /// Overloaded. Gets or sets the double value using the pair of indexes.
        /// </summary>
        /// <param name="row">The zero-based row index.</param>
        /// <param name="column">The zero-based column index.</param>
        /// <returns>The double value at specified point.</returns>
        public T this[int row, int column]
        {
            get
            {
                checkPositive(row, column);
                checkBounds(row + 1, column + 1);

                return this.getItemAt(row, column);
            }
            set
            {
                checkPositive(row, column);
                checkBounds(row + 1, column + 1);

                this.setItemAt(row, column, value);
            }
        }

        /// <summary>
        /// Overloaded. Gets or sets the double value using the pair of indexes.
        /// </summary>
        /// <param name="indexPair">The IndexPair object containing a pair of indexes.</param>
        /// <returns>The double value at specified point.</returns>
        public T this[IndexPair indexPair]
        {
            get { return this[indexPair.row, indexPair.column]; }
            set { this[indexPair.row, indexPair.column] = value; }
        }

        /// <summary>
        /// Returns the value at specified matrix index.
        /// 
        /// Contract: should NOT perform any speed-lowering index-bound checking, because all checking has
        /// been already performed at DoubleMatrix level in this[,] indexer.
        /// </summary>
        /// <param name="row">The ROW!</param>
        /// <param name="column">The COLUMN!</param>
        /// <returns>Value at specified index</returns>
        protected internal abstract T getItemAt(int row, int column);

        /// <summary>
        /// Sets value at specified index.
        /// 
        /// Contract: should NOT perform any speed-lowering index-bound checking, because all checking has
        /// been already performed at DoubleMatrix level in this[,] indexer.
        /// </summary>
        /// <param name="row">The ROW!</param>
        /// <param name="column">The COLUMN!</param>
        /// <param name="value">The VALUE TO SET!</param>
        protected internal abstract void setItemAt(int row, int column, T value);

        public static Matrix<T> operator *(Matrix<T> one, Matrix<T> two)
        {
            return one.multiply(two);
        }

        public static Matrix<T> operator +(Matrix<T> one, Matrix<T> two)
        {
            return one.sum(two);
        }

        public static Matrix<T> operator -(Matrix<T> one)
        {
            return one.negate();
        }

        public abstract int RowCount { get; }
        public abstract int ColumnCount { get; }
        public int ElementCount { get { return RowCount * ColumnCount; } }

        /// <summary>
        /// Inserts the submatrix at the specified point. The current matrix WILL NOT BE STRETCHED
        /// if the submatrix is too large. In this case, exception will be thrown.
        /// </summary>
        /// <param name="subMatrix">The submatrix object.</param>
        /// <param name="i">A zero-based row index</param>
        /// <param name="j">A zero-based column index</param>
        public abstract void layMatrixAt(Matrix<T> subMatrix, int i, int j);

        /// <summary>
        /// Overloaded. Gets the stand-alone submatrix copy at the specified point and with specified size.
        /// </summary>
        /// <param name="i">Row index of the upper-left corner element</param>
        /// <param name="j">Columnt index of the upper-left corner element</param>
        /// <param name="rows">Row count of the submatrix</param>
        /// <param name="columns">Column count of the submatrix</param>
        /// <returns>The submatrix of specified size</returns>
        public abstract Matrix<T> getSubMatrixCopyAt(int i, int j, int rows, int columns);

        /// <summary>
        /// Overloaded. Gets the stand-alone submatrix copy at the specified point.
        /// </summary>
        /// <param name="i">Row index of the upper-left corner element</param>
        /// <param name="j">Column index of the upper-left corner element</param>
        /// <returns>The submatrix of size [RowCount-i; ColumnCount-j]</returns>
        public Matrix<T> getSubMatrixCopyAt(int i, int j)
            { return this.getSubMatrixCopyAt(i, j, RowCount - i, ColumnCount - j); }

        /// <summary>
        /// Overloaded. Gets the binded submatrix for the current matrix.
        /// Changes to the submatrix WILL affect the current.
        /// </summary>
        /// <param name="i">Row index of the upper-left corner element</param>
        /// <param name="j">Column index of the upper-left corner element</param>
        /// <param name="rows">Row count of the submatrix</param>
        /// <param name="columns">Column count of the submatrix</param>
        /// <returns>The binded submatrix of specified size</returns>
        public abstract Matrix<T> getSubMatrixAt(int i, int j, int rows, int columns);

        /// <summary>
        /// Overloaded. Gets the binded submatrix for the current matrix.
        /// Changes to the submatrix WILL affect the current.
        /// </summary>
        /// <param name="i">Row index of the upper-left corner element</param>
        /// <param name="j">Column index of the upper-left corner element</param>
        /// <param name="rows">Row count of the submatrix</param>
        /// <param name="columns">Column count of the submatrix</param>
        /// <returns>The binded submatrix of size [RowCount-i; ColumnCount-j]</returns>
        public Matrix<T> getSubMatrixAt(int i, int j)
            { return this.getSubMatrixAt(i, j, RowCount - i, ColumnCount - j); }

        protected abstract Matrix<T> multiply(Matrix<T> another);
        protected abstract Matrix<T> substract(Matrix<T> another);
        protected abstract Matrix<T> sum(Matrix<T> another);
        protected abstract Matrix<T> negate();

        /// <summary>
        /// Converts the current matrix to a two-dimensional array.
        /// Abstract method, implementation should be provided in every concrete subclass.
        /// </summary>
        /// <returns></returns>
        public abstract T[,] convertToArray();
        
        /// <summary>
        /// Fills the current matrix with elements of matching type stored in a 2D array.
        /// The array size and the current matrix' size should match.
        /// </summary>
        /// <param name="matrix"></param>
        public void convertFromArray(T[,] matrix)
        {
            if (matrix.GetLength(0) != this.RowCount || matrix.GetLength(1) != this.ColumnCount)
                throw new ArgumentException("The size of the array doesn't match with current matrix' size.");

            for (int i = 0; i < this.RowCount; i++)
                for (int j = 0; j < this.ColumnCount; j++)
                    this.setItemAt(i, j, matrix[i, j]);
        }

        // -------------------------------------------------- Inherited from interfaces

        /// <summary>
        /// Creates a deep copy of current object.
        /// </summary>
        /// <returns>The cloned object.</returns>
        public abstract object Clone();

        /// <summary>
        /// Gets the element value at specified index pair.
        /// </summary>
        /// <param name="row">A zero-based row index.</param>
        /// <param name="column">A zero-based column index.</param>
        /// <returns>The value of matrix element at specified point.</returns>
        public object getElementValue(int row, int column) { return this[row, column]; }

        // ------------------------------------------------------------------------------
        // -----------------------------WINDING capabilities-----------------------------

        public T[] unwindToArray(IWinder winder)
        {
            T[] temp = new T[this.ElementCount];

            winder.reset();

            for (int i = 0; i < this.ElementCount; i++)
                temp[i] = this[winder.getNextIndexPair()];

            return temp;
        }

        /// <summary>
        /// Winds a flat array onto current using the IWinder object.
        /// The IWinder object is automatically reset before winding.
        /// IWinder object and current matrix should be have the same dimension (i.e. row count and column count).
        /// </summary>
        /// <param name="winder">An IWinder object. Row and column count should match with current matrix.</param>
        /// <param name="flatMatrix">A single-dimension matrix. Element count should match with current matrix.</param>
        public void windFromArray(IWinder winder, T[] flatMatrix)
        {
            if(flatMatrix.Length!=this.ElementCount)
                throw new ArgumentException("The element count of the current matrix and the element count of the flat matrix must match.");

            winder.reset();
            for (int i = 0; i < this.ElementCount; i++)
            {
                this[winder.getNextIndexPair()] = flatMatrix[i];
            }
        }

        // --------- Service methods

        /// <summary>
        /// Checks if the arguments do not exceed the number of total rows and columns respectively.
        /// Throws exception otherwise.
        /// </summary>
        /// <param name="exceedsRows">Argument suspicious to exceed the number of rows.</param>
        /// <param name="exceedsColumns">Argument suspicious to exceed the number of columns.</param>
        protected void checkBounds(int exceedsRows, int exceedsColumns)
        {
            if (exceedsRows > this.RowCount) throw new ArgumentException("Invalid row count: out of the matrix bounds.");
            if (exceedsColumns > this.ColumnCount) throw new ArgumentException("Invalid column count: out of the matrix bounds.");
        }

        /// <summary>
        /// Checks if the arguments are zero or positive.
        /// </summary>
        protected void checkPositive(params int[] arguments)
        {
            foreach (int a in arguments) if (a < 0) throw new ArgumentException("Negative argument specified.");
        }
    }
}

