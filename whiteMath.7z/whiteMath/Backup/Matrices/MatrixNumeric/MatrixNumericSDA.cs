﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace whiteMath.Matrices
{
    /// <summary>
    /// Matrix containing the single-dimensional array inside.
    /// Is quickest to work, but definitely not-so-understandable.
    /// </summary>
    public class MatrixNumeric_SDA<T,C>: MatrixNumeric<T,C> where C:ICalc<T>, new()
    {
        private Numeric<T,C>[] matrixArray;       // Single-dimensional array containing the matrix
        
        //--------------- CONSTRUCTORS

        /// <summary>
        /// Constructs a new single-dimensional-array-based Matrix object
        /// </summary>
        /// <param name="rows">Height of the matrix</param>
        /// <param name="columns">Width of the matrix</param>
        public MatrixNumeric_SDA(int rows, int columns)
        {
            if (rows <= 0 || columns <= 0) throw new ArgumentException("Witdh and height are both must be non-negative numbers.");
            this.matrixArray = new Numeric<T,C>[rows * columns];
            this.rows = rows;
            this.columns = columns;
        }

        /// <summary>
        /// Constructor "private-only" version
        /// </summary>
        private MatrixNumeric_SDA() { }

        // --------------- Overriding properties of abstract matrix

        /// <summary>
        /// Implementing <see>DoubleMatrix.setItemAt()</see>
        /// </summary>
        protected internal override void setItemAt(int row, int column, Numeric<T,C> value)
        {
            matrixArray[row * this.columns + column] = value;
        }

        /// <summary>
        /// Implementing <see>DoubleMatrix.getItemAt()</see>
        /// </summary>
        protected internal override Numeric<T,C> getItemAt(int row, int column)
        {
            return matrixArray[row * this.columns + column];
        }

        // ------------------ Submatrix operation

        public override Matrix<Numeric<T,C>> getSubMatrixAt(int i, int j, int rows, int columns)
        {
            checkPositive(i, j);
            checkBounds(i + rows, j + columns);

            return new SubmatrixNumeric<T,C>(this, i, j, rows, columns);
        }

        public override void layMatrixAt(Matrix<Numeric<T,C>> subMatrix, int i, int j)
        {
            checkPositive(i,j);
            checkBounds(i + subMatrix.RowCount, j + subMatrix.ColumnCount);

            for(int k=0; k<subMatrix.RowCount; k++)
                for(int m=0; m<subMatrix.ColumnCount; m++)
                    this.setItemAt(i+k, j+m, subMatrix.getItemAt(k,m));
        }

        /// <summary>
        /// Overloaded. Gets the submatrix at the specified point and with specified size.
        /// </summary>
        /// <param name="i">Row index of the upper-left corner element</param>
        /// <param name="j">Columnt index of the upper-left corner element</param>
        /// <param name="rows">Row count of the submatrix</param>
        /// <param name="columns">Column count of the submatrix</param>
        /// <returns>The submatrix of specified size</returns>
        public override Matrix<Numeric<T,C>> getSubMatrixCopyAt(int i, int j, int rows, int columns)
        {
            checkPositive(rows, columns);
            checkBounds(i + rows, j + columns);

            Numeric<T,C>[] ma = new Numeric<T,C>[rows * columns];
            int z=0;

            for (int k = i; k < i + rows; k++)
            {
                Array.Copy(this.matrixArray, this.columns*k + j, ma, z++*columns, columns);
            }

            MatrixNumeric_SDA<T,C> temp = new MatrixNumeric_SDA<T,C>();
            temp.matrixArray = ma;
            temp.rows = rows;
            temp.columns = columns;

            return temp;
        }

        // ------------------ OPERATORS

        public static implicit operator MatrixNumeric_SDA<T,C>(T[,] doubleMatrix)
        {
            MatrixNumeric_SDA<T,C> temp = new MatrixNumeric_SDA<T,C>();

            temp.rows = doubleMatrix.GetLength(0);
            temp.columns = doubleMatrix.GetLength(1);
            temp.matrixArray = new Numeric<T,C>[temp.rows * temp.columns];

            int z=0;
            for (int i = 0; i < temp.rows; i++)
                for (int j = 0; j < temp.columns; j++)
                    temp.matrixArray[z++] = doubleMatrix[i, j];

            return temp;
        }

        public static implicit operator Numeric<T,C>[,](MatrixNumeric_SDA<T,C> matrix)
        {
            Numeric<T,C>[,] temp = new Numeric<T,C>[matrix.rows, matrix.columns];

            int z=0;
            for (int i = 0; i < matrix.rows; i++)
                for (int j = 0; j < matrix.columns; j++)
                    temp[i, j] = matrix.matrixArray[z++];

            return temp;
        }

        public override Numeric<T,C>[,] convertToArray()
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Negates the matrix so that all the elements change their sign to the opposite.
        /// </summary>
        /// <returns></returns>
        protected override Matrix<Numeric<T,C>> negate()
        {
            MatrixNumeric_SDA<T,C> temp = new MatrixNumeric_SDA<T,C>(rows, columns);
            temp.matrixArray = (Numeric<T,C>[])this.matrixArray.Clone();

            for (int i = 0; i < this.ElementCount; i++)
                temp.matrixArray[i] = -temp.matrixArray[i];

            return temp;
        }

        protected override Matrix<Numeric<T,C>> multiply(Matrix<Numeric<T,C>> another)
        {
            if (this.columns != another.RowCount)
                throw new ArgumentException("The column count of the first matrix and the row count of the second matrix must match.");

            MatrixNumeric_SDA<T,C> temp = new MatrixNumeric_SDA<T,C>(this.rows, another.ColumnCount);
            MatrixNumericHelper<T,C>.multiplySimple(this, another, temp);
            return temp;
        }

        protected override Matrix<Numeric<T,C>> substract(Matrix<Numeric<T,C>> another)
        {
            if (this.rows!=another.RowCount || this.columns!=another.ColumnCount)
                throw new ArgumentException("Matrices must be of the same size in order to substract.");

            // If the matrix is SDA, we can do it quick'n'lucky.
            if (this.GetType().IsInstanceOfType(another))
            {
                MatrixNumeric_SDA<T,C> temp = (MatrixNumeric_SDA<T,C>)another;
                MatrixNumeric_SDA<T,C> newMatrix = new MatrixNumeric_SDA<T,C>(this.rows, this.columns);

                for (int i = 0; i < this.ElementCount; i++)
                    newMatrix.matrixArray[i] = this.matrixArray[i] - temp.matrixArray[i];

                return newMatrix;
            }
            // Here comes the bad case
            else
            {
                MatrixNumeric_SDA<T,C> newMatrix = new MatrixNumeric_SDA<T,C>(this.rows, this.columns);

                for (int i = 0; i < this.ElementCount; i++)
                    newMatrix.matrixArray[i] = this.matrixArray[i] - another.getItemAt(i / columns, i % columns);

                return newMatrix;
            }
        }

        protected override Matrix<Numeric<T,C>> sum(Matrix<Numeric<T,C>> another)
        {
            if (this.rows != another.RowCount || this.columns != another.ColumnCount)
                throw new ArgumentException("Matrices must be of the same size in order to sum.");

            // If the matrix is SDA, we can do it quick'n'lucky.
            if (this.GetType().IsInstanceOfType(another))
            {
                MatrixNumeric_SDA<T,C> temp = (MatrixNumeric_SDA<T,C>)another;
                MatrixNumeric_SDA<T,C> newMatrix = new MatrixNumeric_SDA<T,C>(this.rows, this.columns);

                for (int i = 0; i < this.ElementCount; i++)
                    newMatrix.matrixArray[i] = this.matrixArray[i] + temp.matrixArray[i];

                return newMatrix;
            }
            // Here comes the bad case
            else
            {
                MatrixNumeric_SDA<T,C> newMatrix = new MatrixNumeric_SDA<T,C>(this.rows, this.columns);

                for (int i = 0; i < this.ElementCount; i++)
                    newMatrix.matrixArray[i] = this.matrixArray[i] + another.getItemAt(i / columns, i % columns);

                return newMatrix;
            }
        }

        /// <summary>
        /// Provides a deep clone of the current matrix.
        /// </summary>
        /// <returns>The cloned matrix.</returns>
        public override object Clone()
        {
            MatrixNumeric_SDA<T,C> temp = new MatrixNumeric_SDA<T,C>();
            temp.matrixArray = (Numeric<T,C>[])this.matrixArray.Clone();
            temp.rows = this.rows;
            temp.columns = this.columns;

            return temp;
        }
    }
}
