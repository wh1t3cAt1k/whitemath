﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace whiteMath.Matrices
{
    /// <summary>
    /// The class represents the submatrix of a double matrix.
    /// All matrix operations supported, but the changes made to the submatrix will be reflected 
    /// on the parent matrix object. The mechanism uses an encapsulated parent matrix 
    /// reference.
    /// 
    /// An object of this class cannot be instantiated directly.
    /// Call method getSubmatrixAt() for a particular DoubleMatrix object instead.
    /// </summary>
    public class SubmatrixNumeric<T,C>: MatrixNumeric<T,C> where C: ICalc<T>, new()
    {
        protected int offsetRow = 0;
        protected int offsetColumn = 0;

        /// <summary>
        /// Gets the row offset (in the parent matrix) for the current submatrix.
        /// </summary>
        public int RowOffset { get { return offsetRow; } }

        /// <summary>
        /// Gets the column offset (in the parent matrix) for the current submatrix.
        /// </summary>
        public int ColumnOffset { get { return offsetColumn; } }

        protected Matrix<Numeric<T,C>> parent;
        
        /// <summary>
        /// Gets the parent matrix object.
        /// </summary>
        public Matrix<Numeric<T,C>> Parent { get { return parent; } }

        private MatrixType mt;

        internal SubmatrixNumeric(Matrix<Numeric<T,C>> matrix, int rowOffset, int columnOffset, int rows, int columns)
        {
            // TODO: дописать!!!
            if (typeof(MatrixNumeric_SDA<T,C>).IsInstanceOfType(matrix)) mt = MatrixType.SDA; // дописать
            else mt = MatrixType.SDA;

            this.offsetRow = rowOffset;
            this.offsetColumn = columnOffset;

            this.rows = rows;
            this.columns = columns;

            this.parent = matrix;
        }

        protected internal override Numeric<T,C> getItemAt(int row, int column)
        {
            return parent.getItemAt(offsetRow + row, offsetColumn + column);
        }

        protected internal override void setItemAt(int row, int column, Numeric<T,C> value)
        {
            parent.setItemAt(offsetRow + row, offsetColumn + column, value);
        }

        public override Matrix<Numeric<T,C>> getSubMatrixCopyAt(int i, int j, int rows, int columns)
        {
            checkPositive(i, j);
            checkBounds(i + rows, j + columns);

            return parent.getSubMatrixCopyAt(offsetRow + i, offsetColumn + j, rows, columns);
        }
        
        /// <summary>
        /// Lays a matrix over the current, reflecting the changes on the parent Matrix object.
        /// </summary>
        /// <param name="subMatrix">The matrix to lay over the current.</param>
        /// <param name="i">The row coordinate in the current submatrix.</param>
        /// <param name="j">The column coordinate in the current submatrix.</param>
        public override void layMatrixAt(Matrix<Numeric<T,C>> subMatrix, int i, int j)
        {
            this.checkPositive(i, j);
            this.checkBounds(subMatrix.RowCount + i, subMatrix.ColumnCount + j);

            parent.layMatrixAt(subMatrix, offsetRow + i, offsetColumn + j);
        }

        /// <summary>
        /// Converts the current submatrix to a double[,] array. 
        /// </summary>
        /// <returns>A two-dimensional array containing all the elements of the current submatrix.</returns>
        public override Numeric<T,C>[,] convertToArray()
        {
            Numeric<T,C>[,] arr = new Numeric<T,C>[rows, columns];

            for (int i = 0; i < rows; i++)
                for (int j = 0; j < columns; j++)
                    arr[i, j] = parent.getItemAt(offsetRow + i, offsetColumn + j);

            return arr;
        }

        /// <summary>
        /// Returns the COPY of the current submatrix as a stand-alone Matrix object.
        /// The changes made to it will never reflect the parent matrix.
        /// </summary>
        /// <returns></returns>
        public override object Clone()
        {
            return parent.getSubMatrixCopyAt(offsetRow, offsetColumn, rows, columns);
        }

        public override Matrix<Numeric<T,C>> getSubMatrixAt(int i, int j, int rows, int columns)
        {
            checkPositive(rows, columns);
            checkBounds(i + rows, j + columns);

            return new SubmatrixNumeric<T,C>(this, i, j, rows, columns);
        }

        private Matrix<Numeric<T,C>> getMatrixOfSize(int rows, int columns)
        {
            switch (mt)
            {
                case MatrixType.SDA: return new MatrixNumeric_SDA<T,C>(rows, columns);
                default: return new MatrixNumeric_SDA<T,C>(rows, columns);
            }
        }

        protected override Matrix<Numeric<T,C>> multiply(Matrix<Numeric<T,C>> another)
        {
            if (this.ColumnCount != another.RowCount)
                throw new ArgumentException("The column count of the first matrix and the row count of the second matrix must match.");

            Matrix<Numeric<T,C>> temp = getMatrixOfSize(this.rows, another.ColumnCount);
            MatrixNumericHelper<T,C>.multiplySimple(this, another, temp);

            return temp;
        }

        protected override Matrix<Numeric<T,C>> negate()
        {
            Matrix<Numeric<T,C>> temp = getMatrixOfSize(rows, columns);

            for (int i = 0; i < rows; i++)
                for (int j = 0; j < columns; j++)
                    temp[i, j] = -this.getItemAt(i, j);

            return temp;
        }

        protected override Matrix<Numeric<T,C>> sum(Matrix<Numeric<T,C>> another)
        {
            if (this.rows != another.RowCount || this.columns != another.ColumnCount)
                throw new ArgumentException("Matrices must be of the same size in order to sum.");

            Matrix<Numeric<T,C>> temp = getMatrixOfSize(rows, columns);
            MatrixNumericHelper<T,C>.sum(this, another, temp);
            return temp;
        }

        protected override Matrix<Numeric<T,C>> substract(Matrix<Numeric<T,C>> another)
        {
            if (this.rows != another.RowCount || this.columns != another.ColumnCount)
                throw new ArgumentException("Matrices must be of the same size in order to substract.");

            Matrix<Numeric<T,C>> temp = getMatrixOfSize(rows, columns);
            MatrixNumericHelper<T,C>.dif(this, another, temp);
            return temp;
        }
    }
}
