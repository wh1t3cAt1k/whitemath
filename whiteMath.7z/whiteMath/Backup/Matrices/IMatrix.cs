﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace whiteMath.Matrices
{
    /// <summary>
    /// The interface supporting the minimal functionality
    /// to get an item from specified point, and to know
    /// both row and column count of the table.
    /// </summary>
    public interface IMatrix
    {
        int RowCount { get; }
        int ColumnCount { get; }

        object getElementValue(int row, int column);
    }
}
