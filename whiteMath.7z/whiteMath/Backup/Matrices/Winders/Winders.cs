﻿using whiteMath;
using whiteMath.Matrices;

public static class Winders
{
    public static IWinder getZigZagWinder(IMatrix matrix)
    {
        return new ZigZagWinder(matrix);
    }

    public static IWinder getZigZagWinder<T>(T[,] matrix)
    {
        return new ZigZagWinder(matrix.GetLength(0), matrix.GetLength(1));
    }

    public static IWinder getRowByRowWinder(IMatrix matrix)
    {
        return new RowByRowWinder(matrix);
    }

    public static IWinder getRowByRowWinder<T>(T[,] matrix)
    {
        return new RowByRowWinder(matrix.GetLength(0), matrix.GetLength(1));
    }

    public static IWinder getSpiralWinder(IMatrix matrix)
    {
        return new SpiralWinder(matrix);
    }

    public static IWinder getSpiralWinder<T>(T[,] matrix)
    {
        return new SpiralWinder(matrix.GetLength(0), matrix.GetLength(1));
    }

    public static IWinder getChaoticWinder(IMatrix matrix)
    {
        return new ChaoticWinder(matrix);
    }

    public static IWinder getChaoticWinder<T>(T[,] matrix)
    {
        return new ChaoticWinder(matrix.GetLength(0), matrix.GetLength(1));
    }
}
