﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace whiteMath.ArithmeticLong
{
    /// <summary>
    /// A long integer number.
    /// </summary>
    public partial class LongInt : ICloneable
    {
        public static readonly int BASE = 10000;
        private static readonly string digitFormatter = getDigitFormatter();
        private static readonly int fieldLength = (int)Math.Log10(BASE);

        //-----------------------------------
        //---------PRIVATE FIELDS------------
        //-----------------------------------

        private List<int> digits;
        private bool negative;

        //-----------------------------------
        //---------PUBLIC PROPERTIES---------
        //-----------------------------------

        /// <summary>
        /// Returns the length of the current number in BASE-based digits.
        /// <see cref="BASE"/>
        /// </summary>
        public int Length { get { return digits.Count; } }

        /// <summary>
        /// Returns the length of the current number in decimal digits.
        /// </summary>
        public long LengthDecimal
        {
            get
            {
                return LongInt.fieldLength * (this.Length - 1) + (int)Math.Ceiling(Math.Log10(this[this.Length - 1])); 
            }
        }

        /// <summary>
        /// Returns true if the current number is negative
        /// </summary>
        public bool Negative { get { return negative; } }

        /// <summary>
        /// Returns the LongInt digit at specified position.
        /// The digit is evaluated by the base of BASE. :)
        /// </summary>
        /// <param name="digitIndex"></param>
        /// <returns></returns>
        public int this[int digitIndex]
        {
            get { return digits[digitIndex]; }
            internal set { digits[digitIndex] = value; }
        }

        //-----------------------------------
        //-----------CONSTRUCTORS------------
        //-----------------------------------

        /// <summary>
        /// Parameterless constructor, sets the zero value.
        /// </summary>
        public LongInt()
        {
            negative = false;                   // is positive.
            digits = new List<int>() { 0 };    // is zero.
        }

        /// <summary>
        /// The constructor designed to create a pseudo-random LongInt
        /// number, using an integer amount of decimal digits specified by the user.
        /// </summary>
        /// <param name="generator"></param>
        /// <param name="decimalDigitCount"></param>
        public LongInt(Random generator, int decimalDigitCount)
        {
            this.negative = (generator.Next(0, 2) == 0 ? false : true);

            int best = decimalDigitCount / fieldLength;         // how many BASE-based digits are there
            int rest = decimalDigitCount % fieldLength;         // additional digit may be presented

            this.digits = new List<int>(best + (rest > 0 ? 1 : 0));

            for (int i = 0; i < best; i++)
                this.digits.Add(generator.Next(0, BASE));

            if (rest > 0)
                this.digits.Add(generator.Next(0, WhiteMath<int, Calculators.CalcInt>.PowerInteger(10, rest)));
        }

        /// <summary>
        /// Private constructor made for quick calculations.
        /// </summary>
        /// <param name="initialSize"></param>
        private LongInt(int initialSize)
        {
            negative = false;                   // is positive
            digits = new List<int>();          // no digits yet
            digits.Capacity = initialSize;      // sets the initial size.
        }

        /// <summary>
        /// Makes a LongInt from the standard long.
        /// </summary>
        /// <param name="num">The long number to convert into LongInt.</param>
        public LongInt(long num)
        {
            negative = (num < 0);               // set the negative flag
            num = (num > 0 ? num : -num);       // make num positive

            digits = new List<int>();

            do                                  // fill in the digits list
            {
                digits.Add((int)(num % BASE));
                num /= BASE;
            } while (num > 0);
        }

        //-----------------------------------
        //------CONVERSION OPERATORS---------
        //-----------------------------------

        /// <summary>
        /// Performs a conversion of a LongInt number into primitive long.
        /// </summary>
        /// <exception cref="OverflowException">May result in an overflow exception.</exception>
        /// <returns></returns>
        public static explicit operator long(LongInt num)
        {
            long res = 0;

            for (int i = 0; i < num.digits.Count; i++)
            {
                res *= BASE;
                res += num.digits[i];
            }

            return res;
        }

        /// <summary>
        /// Performs an implicit conversion of a long number into LongInt.
        /// </summary>
        /// <param name="num">The long number to convert.</param>
        /// <returns>The LongInt number.</returns>
        public static implicit operator LongInt(long num)
        {
            return new LongInt(num);
        }

        //-----------------------------------
        //------ARITHMETIC OPERATORS---------
        //-----------------------------------

        public static LongInt operator +(LongInt one, LongInt two)
        {
            // Check for negativeness.

            if (!one.negative && two.negative)
            {
                two.negative ^= true;
                LongInt tmp = one - two;
                two.negative ^= true;

                return tmp;
            }
            else if (one.negative && !two.negative)
            {
                one.negative ^= true;
                LongInt tmp = (two - one);
                one.negative ^= true;

                return tmp;
            }

            int maxLength = Math.Max(one.Length, two.Length);
            int minLength = Math.Min(one.Length, two.Length);

            LongInt res = new LongInt(maxLength);
            res.negative = one.negative && two.negative;        // negative only if both are negative,
            // other cases at (*)

            bool shift = false;         // перенос
            int i;

            for (i = 0; i < minLength; i++)
            {
                long digSum = one.digits[i] + two.digits[i] + (shift ? 1 : 0);
                res.digits.Add((int)(digSum % BASE));
                shift = digSum >= BASE;
            }

            if (i < maxLength)
            {
                if (one.Length < maxLength)
                    for (; i < maxLength; i++)
                    {
                        long digSum = two.digits[i] + (shift ? 1 : 0);
                        res.digits.Add((int)(digSum % BASE));
                        shift = digSum >= BASE;
                    }
                else
                    for (; i < maxLength; i++)
                    {
                        long digSum = one.digits[i] + (shift ? 1 : 0);
                        res.digits.Add((int)(digSum % BASE));
                        shift = digSum >= BASE;
                    }
            }

            if (shift)
                res.digits.Add(1);

            return res;
        }

        public static LongInt operator -(LongInt one, LongInt two)
        {
            if (!one.negative && two.negative)
            {
                two.negative ^= true;
                LongInt tmp = one + two;
                two.negative ^= true;

                return tmp;
            }
            else if (one.negative && !two.negative)
            {
                one.negative ^= true;
                LongInt tmp = one + two;
                tmp.negative = true;
                one.negative ^= true;

                return tmp;
            }

            LongInt bigger, smaller;
            bool aMoreB = AbsMore(one, two, out bigger, out smaller);

            // -------- here comes the substracting

            LongInt res = new LongInt(bigger.Length);
            long temp;
            byte shift = 0;
            int i = 0;

            for (; i < smaller.Length; i++)
            {
                temp = bigger.digits[i] - smaller.digits[i] - shift;

                if (temp < 0)
                {
                    shift = 1;
                    temp += BASE;
                }
                else shift = 0;

                res.digits.Add((int)temp);
            }

            for (; i < bigger.Length; i++)
            {
                temp = bigger.digits[i] - shift;

                if (temp < 0)
                {
                    shift = 1;
                    temp += BASE;
                }
                else shift = 0;

                res.digits.Add((int)temp);
            }

            // ---- cut the leading zeroes

            i -= 1;
            while (i > 0 && res.digits[i] == 0)
                res.digits.RemoveAt(i--);

            // ---- deal with negative flag

            if (aMoreB && !one.negative && !two.negative)
                res.negative = false;
            else if (aMoreB && one.negative && two.negative)
                res.negative = true;
            else if (!aMoreB && !one.negative && !two.negative)
                res.negative = true;
            else if (!aMoreB && one.negative && two.negative)
                res.negative = false;

            dealWithZeroes(ref res);
            return res;
        }

        public static LongInt operator *(LongInt one, int two)
        {
            // if we multiply by zero, return a zero number
            if (two == 0) return new LongInt();

            // create the result number

            LongInt res = new LongInt(one.Length + 10);
            res.digits.AddRange(new int[one.Length]);

            int i;
            int remainder = 0;
            long temp;

            // deal with negativeness

            res.negative = one.negative ^ (two < 0);
            if (two < 0) two = -two;

            for (i = 0; i < one.Length; i++)
            {
                temp = one[i] * two + remainder;
                res[i] = (int)(temp % BASE);
                remainder = (int)(temp / BASE);
            }

            while (remainder > 0)
            {
                res.digits.Add(remainder % BASE);
                remainder /= BASE;
            }

            dealWithZeroes(ref res);
            return res;
        }

        /// <summary>
        /// Multiplies one LongInt number by another.
        /// </summary>
        /// <param name="one"></param>
        /// <param name="two"></param>
        /// <returns></returns>
        public static LongInt operator *(LongInt one, LongInt two)
        {
            // if the length of the second number is 1, call another operator
            if (two.Length == 1) return one * (two.digits[0]*(two.negative?-1:1));

            // the resulting number can have double length.
            LongInt res = new LongInt(one.Length + two.Length);
            res.digits.AddRange(new int[one.Length + two.Length]);
            res.negative = one.negative ^ two.negative;

            int i, j;
            int shift;     // перенос
            long temp;      // временный результат

            for (i = 0; i < one.Length; i++)
            {
                shift = 0;

                for (j = 0; j < two.Length; j++)
                {
                    temp = one.digits[i] * two.digits[j] + res.digits[i + j] + shift;
                    shift = (int)(temp / BASE);
                    res.digits[i + j] = (int)(temp - shift * BASE);
                }

                res.digits[i + j] = shift;
            }

            // Cut the leading zeroes

            dealWithZeroes(ref res);
            return res;
        }

        public static LongInt operator /(LongInt one, int two)
        {
            int remainder = 0;

            int i;
            long temp;

            LongInt res = new LongInt(one.Length);

            // Deal with negativeness

            res.negative = one.negative ^ (two < 0);
            if (two < 0) two = -two;

            // Fill in with zeroes

            res.digits.AddRange(new int[one.Length]);

            for (i = one.Length - 1; i >= 0; i--)
            {
                temp = remainder * BASE + one.digits[i];
                res.digits[i] = (int)(temp / two);
                remainder = (int)(temp - res.digits[i] * two);
            }

            // the remainder equals the overall remainder
            // cut the leading zeroes

            dealWithZeroes(ref res);
            return res;
        }

        public static LongInt operator /(LongInt one, LongInt two)
        {
            if (one.Length < two.Length) return new LongInt();                            // zero number should be returned
            if (two.Length == 1) return one / (two.digits[0]*(two.negative?-1:1));        // if the length of the second is 1, make a call to another operator

            // Создать временное число U, равное A
            // Максимальный размер U на цифру больше A, с учетом
            // возможного удлинения A при нормализации
            LongInt u = new LongInt(one.Length + 1);
            u = one.Clone() as LongInt;

            int uShift, vShift, i;
            long temp, temp1, temp2;

            int scale;
            int qGuess, remainder;
            int borrow, carry;

            // ---- Normalize the numbers

            scale = BASE / (two.digits[two.Length - 1] + 1);
            if (scale > 1)
            {
                u *= scale;
                two *= scale;
            }

            int m = u.Length - two.Length;
            int n = two.Length;

            u.digits.Add(0);

            // ---- Result

            LongInt res = new LongInt(m + 1);
            res.digits.AddRange(new int[m + 1]);

            bool oneN = one.negative; u.negative = false;
            bool twoN = two.negative; two.negative = false;

            // ---- main cycle

            for (vShift = m, uShift = n + vShift; vShift >= 0; --vShift, --uShift)
            {
                qGuess = (u[uShift] * BASE + u[uShift - 1]) / two[n - 1];
                remainder = (u[uShift] * BASE + u[uShift - 1]) % two[n - 1];

                while (remainder < BASE)
                {
                    temp2 = two[n - 2] * qGuess;
                    temp1 = remainder * BASE + u[uShift - 2];

                    if ((temp2 > temp1) || (qGuess == BASE))
                    {
                        --qGuess;
                        remainder += two[n - 1];
                    }
                    else break;
                }

                // Теперь qGuess - правильное частное или на единицу больше q
                // Вычесть делитель B, умноженный на qGuess из делимого U,
                // начиная с позиции vJ+i
                carry = 0; borrow = 0;

                // цикл по цифрам two
                for (i = 0; i < n; i++)
                {
                    // получить в temp цифру произведения B*qGuess
                    temp1 = two[i] * qGuess + carry;
                    carry = (int)(temp1 / BASE);
                    temp1 -= carry * BASE;
                    // Сразу же вычесть из U
                    temp2 = u[i + vShift] - temp1 + borrow;
                    if (temp2 < 0)
                    {
                        u[i + vShift] = (int)(temp2 + BASE);
                        borrow = -1;
                    }
                    else
                    {
                        u[i + vShift] = (int)temp2;
                        borrow = 0;
                    }
                }

                // возможно, умноженое на qGuess число B удлинилось.
                // Если это так, то после умножения остался
                // неиспользованный перенос carry. Вычесть и его тоже.

                temp2 = u[i+vShift] - carry + borrow;
                if (temp2 < 0)
                {
                    u[i+vShift] = (int)temp2 + BASE;
                    borrow = -1;
                }
                else
                {
                    u[i+vShift] = (int)temp2;
                    borrow = 0;
                }

                // Прошло ли вычитание нормально ?
                if (borrow == 0)
                { // Да, частное угадано правильно
                    res[vShift] = qGuess;
                }
                else
                { // Нет, последний перенос при вычитании borrow = -1,
                    // значит, qGuess на единицу больше истинного частного
                    res[vShift] = qGuess - 1;
                    // добавить одно, вычтенное сверх необходимого B к U
                    carry = 0;
                    for (i = 0; i < n; i++)
                    {
                        temp = u[i+vShift] + two[i] + carry;
                        if (temp >= BASE)
                        {
                            u[i+vShift] = (int)(temp - BASE);
                            carry = 1;
                        }
                        else
                        {
                            u[i+vShift] = (int)temp;
                            carry = 0;
                        }
                    }
                    u[i+vShift] = u[i+vShift] + carry - BASE;
                }

                // Обновим размер U, который после вычитания мог уменьшиться
                i = u.Length - 1;
                while ((i > 0) && (u[i] == 0)) 
                    u.digits.RemoveAt(i--);
            }
   
            // Если происходило домножение на нормализующий множитель –
            // разделить на него. То, что осталось от U – остаток.
            if (scale > 1)
            {
                two/=scale;
                u/=scale;
            }

            // return negativeness

            u.negative = oneN;
            two.negative = twoN;
            res.negative = oneN ^ twoN;            

            // deal with zeroes and return

            dealWithZeroes(ref res);
            dealWithZeroes(ref u);
            return res;
        }

        public static LongInt operator %(LongInt one, LongInt two)
        {
            if (one < two) return one.Clone() as LongInt;
            else return (one - one / two);
        }

        /// <summary>
        /// Unary minus operator. Negates the number.
        /// </summary>
        /// <param name="num"></param>
        /// <returns></returns>
        public static LongInt operator -(LongInt num)
        {
            LongInt tmp = num.Clone() as LongInt;
            tmp.negative ^= true;

            return tmp;
        }

        // ----------------------------------

        //-----------------------------------
        //------FAST DECIMAL MULTIPLICATION--
        //-----------------------------------

        /// <summary>
        /// Shifts the current number to the left by the specified amount of decimal digits.
        /// Equivalent to multiplication by 10^tenPower.
        /// IS quick.
        /// </summary>
        /// <param name="tenPower">The amount of decimal digits to shift by.</param>
        public void DecimalMultiply(int tenPower)
        {
            if (tenPower < 0) { DecimalDivide(-tenPower); return; }
            this.digits.InsertRange(0, new int[tenPower / fieldLength + (tenPower % fieldLength == 0 ? 0 : 1)]);
        }

        /// <summary>
        /// Shifts the current number to the right by the specified amount of decimal digits.
        /// Equivalent to division by 10^tenPower.
        /// IS quick.
        /// </summary>
        /// <param name="tenPower">The amount of decimal digits to shift by.</param>
        public void DecimalDivide(int tenPower)
        {
            if (tenPower < 0) { DecimalMultiply(-tenPower); return; }

            this.digits.RemoveRange(0, Math.Min(tenPower / fieldLength, this.Length));
            tenPower %= fieldLength;

            if (this.Length > 0)
            {
                int dec = 1;
                for (int i = 0; i < tenPower; i++) dec *= 10;
                this.digits[0] /= dec;
            }
            else this.digits.Add(0);
        }

        //-----------------------------------
        //------SERVICE METHODS--------------
        //-----------------------------------

        /// <summary>
        /// Gets the digit formatter for ToString() output.
        /// </summary>
        /// <returns></returns>
        private static string getDigitFormatter()
        {
            long fieldLength = (long)Math.Log10(BASE);
            return "{0:d" + fieldLength.ToString() + "}";
        }

        /// <summary>
        /// Cuts the leading zeroes in the number.
        /// Then checks whether the result is zero value
        /// and makes it positive.
        /// </summary>
        /// <param name="num"></param>
        /// <returns></returns>
        private static bool dealWithZeroes(ref LongInt num)
        {
            int i = num.Length - 1;

            while (num.digits[i] == 0 && i > 0)
                num.digits.RemoveAt(i--);

            if (num.Length == 1 && num.digits[0] == 0)
            {
                num.negative = false;
                return true;
            }

            return false;
        }

        /// <summary>
        /// Chooses the bigger and the smaller absolute number of two.
        /// </summary>
        /// <param name="one"></param>
        /// <param name="two"></param>
        /// <param name="bigger"></param>
        /// <param name="smaller"></param>
        private static bool AbsMore(LongInt one, LongInt two, out LongInt bigger, out LongInt smaller)
        {
            bool neg1 = one.negative;
            bool neg2 = two.negative;

            one.negative = false;
            two.negative = false;

            bool res = one > two;

            one.negative = neg1;
            two.negative = neg2;

            bigger = res ? one : two;
            smaller = res ? two : one;

            return res;
        }

        //-----------------------------------
        //------COMPARISON OPERATORS---------
        //-----------------------------------

        public static bool operator >(LongInt one, LongInt two)
        {
            if (!one.negative && two.negative) return true;
            else if (one.negative && !two.negative) return false;
            else if (one.negative && two.negative)
            {
                one.negative ^= true;
                two.negative ^= true;

                bool temp = two > one;

                one.negative ^= true;
                two.negative ^= true;

                return temp;
            }

            // ---------------------------
            // --Numbers are both positive
            // ---------------------------

            if (one.Length > two.Length) return true;
            else if (one.Length < two.Length) return false;

            // ------------------
            // --Lengths are same
            // ------------------

            for (int i = one.Length - 1; i >= 0; i--)
                if (one.digits[i] > two.digits[i]) return true;
                else if (one.digits[i] < two.digits[i]) return false;

            return false;
        }

        public static bool operator <(LongInt one, LongInt two)
        {
            return two > one;
        }

        public static bool operator ==(LongInt one, LongInt two)
        {
            // if numbers are of different signs - false.
            if (one.negative ^ two.negative == true) return false;

            // if numbers are of different sizes - false.
            if (one.Length != two.Length) return false;

            // check the digits.
            for (int i = 0; i < one.Length; i++)
                if (one.digits[i] != two.digits[i]) return false;

            return true;
        }

        public static bool operator !=(LongInt one, LongInt two)
        {
            return !(one == two);
        }

        //-----------------------------------
        //------LEFT SHIFTING, RIGHT SHIFTING
        //-----------------------------------

        /// <summary>
        /// Shifts the specified LongInt to the left by howMuch binary digits.
        /// IS NOT quick.
        /// </summary>
        /// <param name="one"></param>
        /// <param name="howMuch"></param>
        public static LongInt operator <<(LongInt one, int howMuch)
        {
            if (howMuch < 0) return one >> (-howMuch);

            LongInt twoPower = WhiteMath<LongInt, whiteMath.Calculators.CalcLongInt>.PowerInteger(2, howMuch);
            one *= twoPower;

            return one;
        }

        /// <summary>
        /// Shifts the specified LongInt to the right by howMuch binary digits.
        /// IS NOT quick.
        /// </summary>
        /// <param name="one"></param>
        /// <param name="howMuch"></param>
        public static LongInt operator >>(LongInt one, int howMuch)
        {
            if (howMuch < 0) return one << (-howMuch);

            LongInt twoPower = WhiteMath<LongInt, whiteMath.Calculators.CalcLongInt>.PowerInteger(2, howMuch);
            one /= twoPower;

            return one;
        }

        //-----------------------------------
        //------OBJECT METHODS OVERRIDE------
        //-----------------------------------

        /// <summary>
        /// Creates a copy of current LongInt number.
        /// </summary>
        /// <returns>A deep copy of current LongInt number.</returns>
        public object Clone()
        {
            LongInt newInt = new LongInt(this.Length);
            newInt.digits.AddRange(this.digits.GetRange(0, this.Length));
            newInt.negative = this.negative;

            return newInt;
        }

        /// <summary>
        /// Checks if two LongInt objects store the same numeric value.
        /// </summary>
        /// <param name="obj">The object to compare to.</param>
        /// <returns>True if true, false if false...</returns>
        public override bool Equals(object obj)
        {
            if (!(obj is LongInt)) return false;

            LongInt compValue = obj as LongInt;
            return this == compValue;
        }

        /// <summary>
        /// Gets the hashing code for current number.
        /// Works very stupidly at the moment, wait for better life.
        /// </summary>
        /// <returns></returns>
        public override int GetHashCode()
        {
            int res = (negative ? 1 : 0);

            for (int i = 0; i < this.Length; i++)
                res += (int)(this.digits[i] % 10);

            return res;
        }

        public override string ToString()
        {
            string result = (negative ? "-" : "");

            // cut the leading zeroes from the elder digit
            result += digits[this.Length - 1];

            for (int i = this.Length - 2; i >= 0; i--)
                result += String.Format(digitFormatter, this.digits[i]);

            return result;
        }

        //-----------------------------------
        //------STRING PARSING METHODS-------
        //-----------------------------------

        /// <summary>
        /// Tries to parse the specified string value into a LongInt number.
        /// If successful, returns true.
        /// False otherwise. In the last case, the result is set to NULL.
        /// </summary>
        /// <param name="value"></param>
        /// <param name="result"></param>
        /// <returns></returns>
        public static bool TryParse(string value, out LongInt result)
        {
            try { result = Parse(value); return true; }
            catch { result = null; return false; }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="value">A string containing a number to convert</param>
        /// <returns></returns>
        public static LongInt Parse(string value)
        {
            // Declare a resulting number

            int digLength = (int)Math.Log10(BASE);
            LongInt res = new LongInt(value.Length / digLength + 1);

            // Set the negative flag

            if (value[0] == '-')
            {
                value = value.Substring(1);
                res.negative = true;
            }

            int digCount = (int)Math.Ceiling((double)value.Length / digLength);

            // Parse the digits

            int i = value.Length - digLength;

            for (; i > 0; i -= digLength)
                res.digits.Add(int.Parse(value.Substring(i, digLength)));

            // Add the "tail"

            res.digits.Add(int.Parse(value.Substring(0, digLength + i)));

            // Cut the leading zeroes

            i = res.digits.Count - 1;

            while (res.digits[i] == 0 && i > 0)
                res.digits.RemoveAt(i--);

            return res;
        }
    }
}
