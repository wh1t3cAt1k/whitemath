﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using WhiteMath = whiteMath.WhiteMath<whiteMath.ArithmeticLong.LongInt, whiteMath.Calculators.CalcLongInt>;

namespace whiteMath.ArithmeticLong
{
    public partial class LongInt
    {
        public static class Helper
        {
            public static LongInt MultiplySimple(LongInt one, LongInt two)
            {
                return one * two;
            }

            /// <summary>
            /// The Karatsuba multiplying algorithm.
            /// The lengths of numbers are completed to the nearest even number.
            /// Requires less memory, but consumes more time, because the completion is likely
            /// to be performed at a large amount of steps.
            /// </summary>
            /// <param name="one"></param>
            /// <param name="two"></param>
            /// <returns></returns>
            public static LongInt MultiplyKaratsuba_EvenNumberCompletion(LongInt one, LongInt two)
            {
                return 1;
            }

            /// <summary>
            /// The Karatsuba multiplying algorithm.
            /// The lengths of numbers are completed to the nearest power of 2.
            /// Requires more memory, but consumes less time than the first version of algorithm.
            /// <see cref="MultiplyKaratsuba_EvenNumberCompletion"/>
            /// </summary>
            /// <param name="one"></param>
            /// <param name="two"></param>
            /// <returns></returns>
            public static LongInt MultiplyKaratsuba_PowerOfTwoCompletion(LongInt one, LongInt two)
            {
                // Для начала - проверочка

                if (one.Length == 1)
                    return two * one.digits[0];
                else if (two.Length == 1)
                    return one * two.digits[0];

                Console.WriteLine("One length: " + one.Length);
                Console.WriteLine("Two length: " + two.Length);

                // Здесь уже нет чисел единичной длины, можем спокойно все делать.
                // Десятичный логарифм числа посчитать просто.

                LongInt bigger = WhiteMath.Abs((one.Length > two.Length ? one : two));

                // Пол десятичного логарифма числа -
                // это количество его цифр минус единица.

                long logTenFloor = bigger.LengthDecimal - 1;
                Console.WriteLine("bigger[n]: " + bigger[bigger.Length - 1]);
                Console.WriteLine("Log10(sh): "+Math.Log10(bigger[bigger.Length-1]));
                Console.WriteLine("Log ten floor: "+logTenFloor);

                // Здесь нужно посчитать пол двоичного логарифма числа.
                // Последовательное умножение делать нельзя - это долго.
                // Воспользуемся формулой перехода от десятичного логарифма к двоичному.

                long logTwoFloor = (long)(logTenFloor / Math.Log(2, 10));
                Console.WriteLine("Log two floor: "+logTwoFloor);

                // Найдем теперь значение пола степени двойки

                LongInt twoPower = WhiteMath.PowerInteger(2, logTwoFloor);
                Console.WriteLine(bigger);
                Console.WriteLine(twoPower);
                Console.WriteLine(twoPower > bigger);

                // Теперь можем позволить себе накладное последовательное умножение на два, пока
                // не достигнем нужной длины.

                while (bigger.Length > twoPower.Length || bigger > twoPower)
                    twoPower.DecimalMultiply(1);

                return 1;
            }
        }
    }
}
