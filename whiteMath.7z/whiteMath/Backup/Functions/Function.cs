﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Globalization;

/* ДАННЫЙ ФАЙЛ СОДЕРЖИТ определение класса FUNCTION, а также набор вспомогательных математических функций.
 * Объявлен также интерфейс IFunction, обеспечивающий функциональность выдачи значения по аргументу
 * 
 * Реализовать: 
 * 1. Длинную целочисленную и длинную вещественную арифметику.
 * 2. Функции: факториал, гамма-функция и т.п.

/*
 * СПИСОК СОКРАЩЕНИЙ ДЯ ПРОСТЕЙШИХ МАТЕМАТИЧЕСКИХ ФУНКЦИЙ,
 * вызываемых в массиве действий.
 * 
 * x        -- R:x
 * x+y      -- +:x,y
 * x-y      -- -:x,y
 * x*y      -- *:x,y
 * x/y      -- /:x,y
 * x^y      -- ^:x,y
 * |x|      -- |:x
 * [x]      -- [:x
 * sqrt(x)  -- Ь:x
 * sin(x)   -- Й:x
 * cos(x)   -- Ц:x
 * tg(x)    -- У:x
 * arcsin(x)-- К:x
 * arccos(x)-- Е:x
 * arctg(x) -- Н:x
 * ctg(x)   -- Г:x
 * sinh(x)  -- Ф:x
 * cosh(x)  -- Ы:x
 * ln(x)    -- В:x
 * lg(x)    -- А:x
 * log(x,a) -- Л:x,a
 * exp(x)   -- Э:x 
 * sgn(x)   -- ?:x
 * if(x>0) return y else return z -- >:x,y,z 
 * if(x=0) return y else return z -- =:x,y,z
 * if(x>=0) return y else return z -- }:x,y,z
 * if(x<0) return y else return z -- <:x,y,z
 * if(x!=0) return y else return z -- _:x,y,z
 * if(x<=0) return y else return z -- {:x,y,z

 * x,y,z - метаобозначение операндов.
 * На их местах в синтаксисе действия могут быть:
 * 
 * 1) символ $ - обращение к результату предыдущего действия
 * 2) $n$, где n - число - обращение к результату действия за номером n.
 *      внимание! нумерация действий начинается с нуля, n должно быть меньше номера текущего действия.
 * 3) %n%, где n - число - обращение к значению вложенной функции за номером n.
 *      внимание! нумерация функций начинается с нуля.
 * 4) символ ! - обращение к значению переменной
 * 5) #errormessage# - вызывает выброс исключения с указанным сообщением об ошибке.
 * 5) число.
 *      внимание! разделитель целой и дробной части - ТОЧКА!
 */

namespace whiteMath.Functions
{
    /// <summary>
    /// The generic function interface.
    /// </summary>
    /// <typeparam name="TypeArg">The type of the function argument</typeparam>
    /// <typeparam name="TypeValue">The type of the function value</typeparam>
    public interface IFunction<TypeArg, TypeValue>
    {
        TypeValue this[TypeArg x] { get; }
        TypeValue Value(TypeArg x);
    }

    public class Function: IFunction<double, double>
    {
        public double this[double x] { get { return Value(x); } }

        delegate double singleAct(double x);
        delegate double doubleAct(double x, double y);
        delegate bool tripleCheck(double x);

        protected char argument;
        protected List<IFunction<double, double>> composedFunc;
        protected List<string> actions;
        
        private double[] actionResults;

        /// <summary>
        /// A special constructor for AnalyticFunction class
        /// </summary>
        protected Function()
        { }

        /// <summary>
        /// Creates a new function using the specified action list
        /// </summary>
        /// <param name="actions"></param>
        public Function(List<string> actions)
        {
            this.actions = actions;
            composedFunc = new List<IFunction<double,double>>();
        }

        public Function(List<string> actions, List<IFunction<double,double>> composedFunctions)
        {
            this.actions = actions;
            this.composedFunc = composedFunctions;
        }

        public double Value(double x) // вычисление значения функции по значению аргумента
        {
            singleAct act1;
            doubleAct act2;
            tripleCheck act3;

            actionResults = new double[actions.Count];

            for (int i=0; i<actions.Count; i++)
            {
                string str = actions[i];

                if (str == null || str.Trim() == "") throw new FunctionActionSyntaxException("cтрока действия за номером " + i + " является пустой.");

                act1 = new singleAct(Functions.Ret);
                act2 = new doubleAct(Functions.Sum);
                act3 = new tripleCheck(Functions.Equals);

                bool binary = true; // бинарное действие или унарное

                if (str[1] != ':' || str.LastIndexOf(':') != 1)
                    throw new FunctionActionSyntaxException("в строке действия должен использоваться один (и только один!) символ ':'. Данный символ должен стоять на второй позиции, отделяя символ операции от операндов.");

                str = str.Replace(":", ""); // удаляем технический символ ':'
                if (str.IndexOf('#') == -1) str = str.Replace(" ", ""); // удаляем все пробелы, если нет сообщений об ошибке
                else
                {
                    string tmp = "";
                    bool insideErrorMsg = false;

                    for (int j = 0; j < str.Length; j++)
                    {    
                        if (str[j] == '#') insideErrorMsg = !insideErrorMsg;
                        if (str[j] != ' ' || insideErrorMsg) tmp += str[j];
                    }

                    str = tmp;
                }

                int ind = str.IndexOf(',');
                double a, b;
                string operand1, operand2;

                switch(str[0].ToString())
                {
                    case "R": binary = false; act1 = new singleAct(Functions.Ret); break;
                    case "+": act2 = new doubleAct(Functions.Sum); break;
                    case "-": act2 = new doubleAct(Functions.Dif); break;
                    case "*": act2 = new doubleAct(Functions.Mul); break;
                    case "/": act2 = new doubleAct(Functions.Div); break;
                    case "^": act2 = new doubleAct(Math.Pow); break;
                    case "|": binary = false; act1 = new singleAct(Math.Abs); break;
                    case "[": binary = false; act1 = new singleAct(Math.Floor); break;
                    case "Й": binary = false; act1 = new singleAct(Math.Sin); break;
                    case "Ц": binary = false; act1 = new singleAct(Math.Cos); break;
                    case "У": binary = false; act1 = new singleAct(Math.Tan); break;
                    case "К": binary = false; act1 = new singleAct(Math.Asin); break;
                    case "Е": binary = false; act1 = new singleAct(Math.Acos); break;
                    case "Н": binary = false; act1 = new singleAct(Math.Atan); break;
                    case "Г": binary = false; act1 = new singleAct(Functions.Ctg); break;
                    case "Ф": binary = false; act1 = new singleAct(Math.Sinh); break;
                    case "Ы": binary = false; act1 = new singleAct(Math.Cosh); break;
                    case "В": binary = false; act1 = new singleAct(Math.Log); break;
                    case "А": binary = false; act1 = new singleAct(Math.Log10); break;
                    case "Ь": binary = false; act1 = new singleAct(Math.Sqrt); break;
                    case "Л": act2 = new doubleAct(Functions.Log); break;
                    case "Э": binary = false; act1 = new singleAct(Math.Exp); break;
                    case "?": binary = false; act1 = new singleAct(Functions.Sgn); break;
                    case ">": case "=": case "}": case "<": case "{": case "_": goto CONDITION;
                    default: throw new FunctionActionSyntaxException("неизвестное обозначение функции в списке действий."); 
                }

                if (binary)
                {
                    if (ind == -1) throw new FunctionActionSyntaxException("операнды бинарного действия должны перечисляться через запятую.");
                    if (ind != str.LastIndexOf(',')) throw new FunctionActionSyntaxException("бинарное действие должно содержать два операнда, перечисленные через запятую.");

                    operand1 = str.Substring(1, ind - 1);
                    operand2 = str.Substring(ind + 1);

                    try
                    {
                        a = operandMeaning(operand1, composedFunc, actionResults, i, x);
                        b = operandMeaning(operand2, composedFunc, actionResults, i, x);
                    }
                    catch (Exception xxx)
                    { throw new Exception("Ошибка при выполнении действия " + i + ". " + xxx.Message); }

                    double res; // результат операции
                    try { res = act2(a, b); }
                    catch { res = double.NaN; }

                    actionResults[i] = res;
                    goto RETURNER;
                }
                else
                {
                    if (ind != -1) throw new FunctionActionSyntaxException("недопустимо содержание запятых в унарном действии - она разделяет операнды в бинарных и тернарных действиях. Для разделителя дробной и целой части чисел используется точка.");
                    operand1 = str.Substring(1);

                    try { a = operandMeaning(operand1, composedFunc, actionResults, i, x); }
                    catch (Exception xxx)
                    {
                        if (xxx is FunctionActionUserThrownException) throw;
                        throw new Exception("Ошибка при выполнении действия " + i + ". " + xxx.Message); 
                    }

                    double res;
                    try { res = act1(a); }
                    catch { res = double.NaN; }

                    actionResults[i] = res;
                    goto RETURNER;
                }

            CONDITION: // выполняется в случае условного оператора действия: >, = , } 

                if (i == 0) throw new FunctionActionSyntaxException("недопустимо использование условных операторов в нулевом действии.");
                
                // объявим дополнительные переменные, так как действие тернарное.
                    int ind2 = str.LastIndexOf(',');
                    double c;
                
                if(ind==-1 || ind2==ind)
                    throw new FunctionActionSyntaxException("условный оператор действия должен содержать три операнда, перечисленных через запятую.");

                operand1 = str.Substring(1, ind - 1);
                operand2 = str.Substring(ind + 1, ind2-ind-1);
                string operand3 = str.Substring(ind2+1);

                try
                {
                    a = operandMeaning(operand1, composedFunc, actionResults, i, x);
                }
                catch (Exception xxx)
                {
                    if (xxx is FunctionActionUserThrownException) throw;
                    throw new Exception("Ошибка при выполнении действия " + i + ". " + xxx.Message); 
                }

                switch(str[0])
                {
                    case '>': act3 = new tripleCheck(Functions.More); break;
                    case '<': act3 = new tripleCheck(Functions.Less); break;
                    case '=': act3 = new tripleCheck(Functions.Equals); break;
                    case '}': act3 = new tripleCheck(Functions.MoreQ); break;
                    case '{': act3 = new tripleCheck(Functions.LessQ); break;
                    case '_': act3 = new tripleCheck(Functions.EqualsNot); break;
                }

                if (act3(a)) 
                    try
                        {   
                            b = operandMeaning(operand2, composedFunc, actionResults, i, x);
                            actionResults[i] = b;
                        }
                    catch (Exception xxx)
                        {
                            if (xxx is FunctionActionUserThrownException) throw;
                            throw new Exception("Ошибка при выполнении действия " + i + ". " + xxx.Message); 
                        }                        
                else
                    try
                        {
                            c = operandMeaning(operand3, composedFunc, actionResults, i, x);
                            actionResults[i] = c;
                        }
                    catch (Exception xxx)
                        {
                            if (xxx is FunctionActionUserThrownException) throw;
                            throw new Exception("Ошибка при выполнении действия " + i + ". " + xxx.Message);
                        }
            
            RETURNER: ; 
            }

            return actionResults[actionResults.Length - 1];
        }
        private double operandMeaning(string operand, List<IFunction<double,double>> composedFunc, double[] actionResults, int num, double x)
        {
            if (operand == null || operand == "") throw new FunctionActionSyntaxException("не указан один из операндов.");

            int negflag=1;
            // если перед операндом стоит знак "минус", то negflag умножается на -1.
            if (operand[0] == '-') { negflag = -1; operand = operand.Substring(1); }

            if (char.IsDigit(operand[0])) // обращение к числовому значению
            { try { double tmp = double.Parse(operand.Replace(".", CultureInfo.CurrentCulture.NumberFormat.NumberDecimalSeparator)); return negflag * tmp; } catch { throw new Exception("Ошибка синтаксиса действия: неизвестный операнд в команде-действии."); } }
            else if (operand.Length == 1 && operand[0] == '!') return negflag * x; // обращение к значению аргумента
            else if (operand.Length == 1 && operand[0] == '$') // обращение к предыдущему действия
            {
                if (num <= 0) throw new FunctionActionSyntaxException("обращение к предыдущему действию из нулевого действия.");
                return negflag * actionResults[num - 1];
            }
            else if (operand[0] == '$') // обращение к результату выполненного действия по номеру
            {
                if (operand.Length <= 2 || operand.LastIndexOf('$') != operand.Length - 1) throw new Exception("Ошибка синтаксиса действия: неверно указано обращение к результату действия по номеру.");

                operand = operand.Replace("$", "");
                int callOperationNum = -1;
                try
                {
                    callOperationNum = int.Parse(operand);
                }
                catch { throw new FunctionActionSyntaxException("неизвестный номер действия, указанный в обращении."); }
                if (callOperationNum >= num) throw new FunctionActionSyntaxException("попытка рефлексивного обращения в действии или попытка обращения к еще не выполненному (следующему) действию.");
                return negflag * actionResults[callOperationNum]; // возвращаем значение действия по номеру
            }
            else if (operand[0] == '%') // вызов результата вложенной функции по номеру
            {
                if (operand.Length <= 2 || operand.LastIndexOf('%') != operand.Length - 1) throw new FunctionActionSyntaxException("неверно указано обращение к результату вложенной функции.");

                operand = operand.Replace("%", "");

                int callFuncNum = -1;

                try
                {
                    callFuncNum = int.Parse(operand);
                }
                catch { throw new FunctionActionSyntaxException("неверно указан номер функции в обращении."); }

                if (callFuncNum < 0 || callFuncNum >= composedFunc.Count)
                    throw new FunctionActionSyntaxException("вложенной функции с указанным номером не существует (нумерация начинается с нуля).");

                return negflag * composedFunc[callFuncNum].Value(x);
            }
            else if (operand[0] == '#') // пользовательское сообщение об ошибке
            {
                if (operand.LastIndexOf('#') != operand.Length - 1) throw new FunctionActionSyntaxException("пользовательское сообщение об ошибке в синтаксисе действия должно находиться между двумя символами #.");
                throw new FunctionActionUserThrownException(operand.Remove(0, 1).Remove(operand.Length - 2));
            }

            throw new FunctionActionSyntaxException("неизвестный формат строки действия.");
        }

        //TODO: переписать интеграл, чтобы считал по-человечески
        public double Integral(double xMin, double xMax, double xStep)
        {
            double integralSum=0;

            if (xStep <= 0) throw new ArgumentException("Для подсчета интегральных сумм шаг должен быть больше нуля.");

            for (double i = xMin; i<xMax; i += xStep)
            {
                if (this[i] == double.NaN) return double.NaN;
                if (this[i] == double.PositiveInfinity) return double.PositiveInfinity;
                if (this[i] == double.NegativeInfinity) return double.NegativeInfinity;
                //предыдущее спорно. есть предложение выкидывать здесь эксепшн

                if(!(this[i]*this[i-xStep]<=0)) integralSum += (this[i] + this[i+xStep])/2 * xStep;
            }

            return integralSum;
        }
    }

    public static class MathFunctions
    {
        public static readonly IFunction<double,double> gamma = new GammaFunction();
        public static readonly IFunction<double,double> factorialLogarithmic = new FactorialLogarithmic();
        public static readonly IFunction<long,long> factorial = new Factorial();
    }

    #region FunctionWorkForDelegates

    internal static class Functions
    {
        internal static double Sum(double a, double b)
        { return a+b; }

        internal static double Dif(double a, double b)
        { return a-b; }

        internal static double Mul(double a, double b)
        { return a*b; }

        internal static double Div(double a, double b)
        { return a/b; }

        internal static double Ret(double a)
        { return a; }

        internal static double Ctg(double a)
        { return 1 / Math.Tan(a); }

        internal static double Sgn(double a)
        { return Math.Sign(a); }

        internal static bool More(double a)
        { return (a > 0); }

        internal static bool Less(double a)
        { return (a < 0); }

        internal static bool MoreQ(double a)
        { return (a >= 0); }

        internal static bool LessQ(double a)
        { return (a <= 0); }

        internal static bool Equals(double a)
        { return (a == 0); }

        internal static bool EqualsNot(double a)
        { return (a != 0); }

        internal static double Log(double a, double b)
        {
            return Math.Log(a, b);
        }
    }

    #endregion

    #region OtherFunctionClasses

    internal struct GammaFunction : IFunction<double,double> // гамма-функция вещественного аргумента не дописано
    {
        public double this[double x] { get { return this.Value(x); } }
        public double Value(double x) { return 0; }
    }

    internal struct FactorialLogarithmic : IFunction<double,double> // логарифмический факториал - высокая скорость, низкая точность
    {
        public double this[double x] { get { return this.Value(x); } }

        public double Value(double x)
        {
            if (x < 1) return 1;

            double tmp=0;

            for (int i = 2; i <= x; i++)
                tmp += Math.Log(i);

            return Math.Exp(tmp);
        }
    }

    internal struct Factorial : IFunction<long, long>
    {
        public long this[long x] { get { return this.Value(x); } }

        public long Value(long x)
        {
            if (x < 1) return 1;

            long tmp = 2;
            for (int i = 2; i <= x; i++) tmp *= i;

            return tmp;
        }
    }

    #endregion
}
